"""Read exact Git trees and retained logs; execute no project code or tests."""

import gzip
import hashlib
import json
import posixpath
import re
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import unquote

ROOT = Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906')
PUB = Path('/Users/acehack/.zeta/agents/codex/Zeta-compiled-evidence-publication-20260907')
OWN = Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906')
BASE = '38b3acd14f0fc07449ace1b78311959f249468ed'
IMPORT = '2276d608c504d9cb99f6564e3ba24e9abd852991'
SOURCE = 'afce96353549a27937dc8b5626532c8aca5ec026'
FINAL = 'c1e6f0497afcc5078b03bfe8e797dc12e684cf58'
HC8 = '8c2434003e638b36c347fb47a9397e4a848c041f'
PROJECT_BASE = '1393e65b439cf7a4b2a5018eeef37fed75d7d1bc'
DOC_BASE = '5cdd7a6568fcf250575a0d6d814434c3bc3c5214'


def git(repo, *args):
    return subprocess.run(['git', *args], cwd=repo, capture_output=True,
                          check=True, timeout=30).stdout


def identity(raw):
    return {'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest()}


def blob(repo, ref, path):
    return git(repo, 'show', ref + ':' + path)


def changes(repo, a, b):
    fields = git(repo, 'diff', '--name-status', '--no-renames', '-z', a, b).split(b'\0')
    assert fields.pop() == b'' and len(fields) % 2 == 0
    result = {fields[i + 1].decode(): fields[i].decode() for i in range(0, len(fields), 2)}
    assert len(result) <= 512
    return result


def tree(repo, ref, paths):
    result = {}
    for row in git(repo, 'ls-tree', '-r', '-z', ref, '--', *paths).split(b'\0'):
        if row:
            metadata, path = row.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            result[path.decode()] = {'Mode': mode, 'Type': kind, 'Blob': oid}
    return result


def retained(path):
    raw = path.read_bytes()
    assert len(raw) <= 256 * 1024
    inputs.append({'Path': str(path), **identity(raw)})
    return raw


inputs = []
copy_raw = retained(PUB / '.git/precision-publication-source-import-1.json')
copy = json.loads(copy_raw)
modes_raw = retained(PUB / '.git/precision-publication-source-modes-1.json')
modes = json.loads(modes_raw)
existing = json.loads(retained(PUB / '.git/precision-publication-existing-import-1.json'))
assert copy['Source'] == SOURCE and copy['FreshMainBase'] == BASE
assert copy['ProjectPatchBase'] == PROJECT_BASE
assert existing['Source'] == SOURCE and existing['ExistingDocPatchBase'] == DOC_BASE
roster = copy['NewFiles']
paths = [row['Path'] for row in roster]
assert len(paths) == len(set(paths)) == 212
assert [row['Path'] for row in modes] == paths
assert len(existing['Documents']) == len(set(existing['Documents'])) == 5
project_paths = ['src/Bayesian/Bayesian.fsproj', 'tests/Bayesian.Tests/Bayesian.Tests.fsproj']
initial_changes = changes(PUB, BASE, IMPORT)
final_changes = changes(PUB, BASE, FINAL)
selected = sorted(final_changes)
trees = {(repo, ref): tree(repo, ref, selected) for repo, ref in
         [(ROOT, SOURCE), (PUB, BASE), (PUB, IMPORT), (PUB, FINAL)]}
new_rows = []
for row, mode in zip(roster, modes, strict=True):
    path = row['Path']
    assert initial_changes[path] == 'A' and path not in trees[PUB, BASE]
    assert trees[ROOT, SOURCE][path] == trees[PUB, IMPORT][path]
    assert trees[PUB, IMPORT][path]['Mode'] == mode['Mode']
    raw = blob(ROOT, SOURCE, path)
    assert identity(raw) == {k: row[k] for k in ['Bytes', 'Sha256']}
    assert raw == blob(PUB, IMPORT, path)
    new_rows.append({'Path': path, **trees[PUB, IMPORT][path], **identity(raw)})

expected_paths = set(paths + project_paths + existing['Documents'] +
                     [existing[k] for k in ['CompletedWorkitem', 'RemovedBacklog', 'CompletionEvent']])
assert set(initial_changes) == expected_paths
assert len(initial_changes) == 222  # 221 rename-aware entries conceal the deleted old path.
assert initial_changes[existing['RemovedBacklog']] == 'D'
for key in ['CompletedWorkitem', 'CompletionEvent']:
    path = existing[key]
    assert initial_changes[path] == 'A'
    assert trees[PUB, IMPORT][path] == trees[ROOT, SOURCE][path]

three_way = []
with tempfile.TemporaryDirectory(dir=OWN / '.git', prefix='kernel-review-merge-') as temp:
    scratch = Path(temp)
    for path in existing['Documents'] + project_paths:
        ancestor = DOC_BASE if path in existing['Documents'] else PROJECT_BASE
        # Reconstruct parent patch composition without changing any index/tree.
        versions = [blob(PUB, BASE, path), blob(ROOT, ancestor, path), blob(ROOT, SOURCE, path)]
        files = [scratch / str(i) for i in range(3)]
        for file, raw in zip(files, versions, strict=True):
            file.write_bytes(raw)
        result = subprocess.run(['git', 'merge-file', '-p', *map(str, files)], cwd=OWN,
                                capture_output=True, timeout=30, check=True)
        expected = blob(PUB, IMPORT, path)
        assert result.stdout == expected and result.stderr == b''
        assert trees[PUB, BASE][path]['Mode'] == trees[PUB, IMPORT][path]['Mode']
        three_way.append({'Path': path, 'Ancestor': ancestor,
                          'FreshMain': identity(versions[0]), 'OldBase': identity(versions[1]),
                          'RootSource': identity(versions[2]), 'Result': identity(expected)})

later_pairs = [
    ('719a2a5f4', '6bee7644ce1022ff69634877ea2dab2b7a059b6e'),
    ('73c966f15', '005573f869e7f63372a5ce5b1fda707fa7daefc7'),
    ('424c853da', 'e623d2d29959a4d161547d3ca185d3722cbcdcc3'),
    (FINAL, 'a184a1bb3cdcee0f428870d8a6928548bdbf3994'),
]
later = []
for published, original in later_pairs:
    published = git(PUB, 'rev-parse', published).decode().strip()
    delta = changes(PUB, published + '^', published)
    assert delta == changes(ROOT, original + '^', original)
    assert tree(PUB, published, list(delta)) == tree(ROOT, original, list(delta))
    left = git(PUB, 'diff', '--binary', '--full-index', published + '^', published)
    right = git(ROOT, 'diff', '--binary', '--full-index', original + '^', original)
    assert left == right
    later.append({'PublicationCommit': published, 'SourceCommit': original,
                  'Paths': delta, 'ExactDiff': identity(left)})

for path, status in final_changes.items():
    assert not path.startswith(('.agents/claims/', '.codex/claims/', '.claude/claims/'))
    if status != 'D':
        raw = blob(PUB, FINAL, path)
        assert raw == (PUB / path).read_bytes()
        assert trees[PUB, FINAL][path]['Mode'] == ('100755' if (PUB / path).stat().st_mode & 0o111 else '100644')

# Markdown destination census is intentionally a finite static scanner, with
# unresolved anchors retained for manual review instead of a general-parser claim.
all_names = set(git(PUB, 'ls-tree', '-r', '--name-only', FINAL).decode().splitlines())
links = []
issues = []
for path in selected:
    if not path.endswith('.md') or final_changes[path] == 'D':
        continue
    text = blob(PUB, FINAL, path).decode()
    text = re.sub(r'^```[^\n]*\n.*?^```[^\n]*$', '', text, flags=re.M | re.S)
    destinations = re.findall(r'\[[^\]\n]+\]\(([^)\n]+)\)', text)
    destinations += re.findall(r'^\[[^\]\n]+\]:\s*(\S+)', text, flags=re.M)
    for value in destinations:
        destination = value.split(' "', 1)[0].strip('<>')
        if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:', destination):
            continue
        local, _, anchor = unquote(destination).partition('#')
        if local.startswith('/Users/'):
            links.append({'From': path, 'To': destination, 'HistoricalAbsoluteLocator': True})
            continue
        target = posixpath.normpath(posixpath.join(posixpath.dirname(path), local)) if local else path
        if local.startswith('/'):
            target = local.lstrip('/')
        exists = target in all_names or any(p.startswith(target.rstrip('/') + '/') for p in all_names)
        record = {'From': path, 'To': destination, 'Target': target, 'Exists': exists}
        links.append(record)
        if not exists:
            issues.append(record)

# Independently audit the source-bound full-gate archive already in c1.
manifest_path = 'docs/research/precision-gate-kernels/2026-09-08/integration-validation/manifest.json'
manifest_raw = blob(PUB, FINAL, manifest_path)
manifest = json.loads(manifest_raw)
assert manifest['FullGateHead'] == SOURCE and manifest['All18ExecutedChecksPassed'] is True
gate_records = []
for row in manifest['Artifacts']:
    path = posixpath.join(posixpath.dirname(manifest_path), row['File'])
    stored = blob(PUB, FINAL, path)
    raw = gzip.decompress(stored)
    assert identity(stored) == {'Bytes': row['StoredBytes'], 'Sha256': row['StoredSha256']}
    assert identity(raw) == {'Bytes': row['Bytes'], 'Sha256': row['Sha256']}
    original_path = Path(row['OriginalPath'])
    if not original_path.is_absolute():
        original_path = ROOT / original_path
    assert raw == original_path.read_bytes()
    gate_records.append({'Path': path, **identity(raw), 'OriginalMatches': True})
for row in manifest['SourceFiles']:
    assert identity(blob(PUB, FINAL, row['Path'])) == {k: row[k] for k in ['Bytes', 'Sha256']}

fresh_gate = {}
for name in ['start.json', 'stdout', 'stderr', 'process.json']:
    raw = retained(PUB / '.git/precision-publication-full-preflight-1' / name)
    fresh_gate[name] = identity(raw)
    if name.endswith('.json'):
        fresh_gate[name]['Value'] = json.loads(raw)
    elif name == 'stdout':
        assert '✓ preflight: all 18 executed check(s) passed.' in raw.decode()
assert fresh_gate['start.json']['Value']['Head'] == fresh_gate['process.json']['Value']['Head'] == FINAL
assert fresh_gate['process.json']['Value']['Exit'] == 0

before = blob(ROOT, HC8 + '^', 'docs/ALIGNMENT.md')
after = blob(ROOT, HC8, 'docs/ALIGNMENT.md')
def parts(raw):
    start = raw.index(b'### HC-8 ')
    end = raw.index(b'### HC-9 ', start)
    section = raw[start:end]
    paragraphs = [p for p in section.split(b'\n\n') if p.startswith(b'Never use dialectical propagators')]
    assert len(paragraphs) == 1
    return raw[:start], section, raw[end:], paragraphs[0]
a, b = parts(before), parts(after)
assert a[0] == b[0] and a[2] == b[2] and a[3] == b[3]
hc8 = {'Commit': HC8, 'Before': identity(before), 'After': identity(after),
       'Operative': identity(b[3]), 'BeforeSection': identity(a[1]),
       'AfterSection': identity(b[1]), 'OutsideBeforeIdentical': True,
       'OutsideAfterIdentical': True, 'OperativeIdentical': True}
assert hc8['Operative']['Sha256'] == '7b1adedd97e4e6d640fa9b6bff493811f7f0d89146d5a422f0147e7a543cd93f'
assert tree(ROOT, HC8, ['docs/ALIGNMENT.md'])['docs/ALIGNMENT.md']['Mode'] == tree(ROOT, HC8+'^', ['docs/ALIGNMENT.md'])['docs/ALIGNMENT.md']['Mode']

result = {'PublicationBase': BASE, 'PublicationImport': IMPORT, 'PublicationFinal': FINAL,
          'RootSource': SOURCE, 'Inputs': inputs, 'CopiedNewFiles': new_rows,
          'InitialChanges': initial_changes, 'FinalChanges': final_changes,
          'ThreeWayExistingFiles': three_way, 'LaterExactImports': later,
          'ChangedWorkingFilesMatchFinal': True, 'NoChangedClaimPaths': True,
          'RelativeLinks': links, 'UnresolvedLinkDestinations': issues,
          'ArchivedRootGate': {'Manifest': identity(manifest_raw), 'Records': gate_records},
          'FreshPublicationGate': fresh_gate, 'HC8': hc8,
          'ReviewExecution': 'Git and independent metadata bookkeeping only; no project source/test execution'}
print(json.dumps(result, indent=2, sort_keys=True))
