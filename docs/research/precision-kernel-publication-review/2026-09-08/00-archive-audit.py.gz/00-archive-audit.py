"""Audit committed publication evidence against its retained original bytes."""
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

P = Path('/Users/acehack/.zeta/agents/codex/Zeta-compiled-evidence-publication-20260907')
H = 'e15821f4ab16ea70d16469d17fdb5d0252e00dd5'
C = 'c1e6f0497afcc5078b03bfe8e797dc12e684cf58'
D = 'docs/research/precision-gate-kernels/2026-09-08/publication-validation'


def git(*args):
    return subprocess.run(['git', *args], cwd=P, capture_output=True, check=True, timeout=30).stdout


def identity(raw):
    return {'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest()}


changed = git('diff', '--name-status', '--no-renames', C, H).decode().splitlines()
assert len(changed) == 36
assert [row for row in changed if row.startswith('M\t')] == [
    'M\tdocs/research/2026-09-08-precision-gate-kernels-native-reference-replay.md']
assert all(row.startswith('M\t') or row.startswith('A\t' + D + '/') for row in changed)
assert git('diff', C, H, '--', 'src', 'tests', 'bench', 'docs/ALIGNMENT.md') == b''
manifest_raw = git('show', H + ':' + D + '/manifest.json')
manifest = json.loads(manifest_raw)
assert manifest['Head'] == C and len(manifest['Artifacts']) == 33
records = []
for row in manifest['Artifacts']:
    path = D + '/' + row['File']
    stored = git('show', H + ':' + path)
    assert stored == (P / path).read_bytes()
    raw = gzip.decompress(stored)
    assert identity(stored) == {'Bytes': row['StoredBytes'], 'Sha256': row['StoredSha256']}
    assert identity(raw) == {k: row[k] for k in ['Bytes', 'Sha256']}
    original = Path(row['OriginalPath'])
    if not original.is_absolute():
        original = P / original
    assert raw == original.read_bytes()
    records.append({'Path': path, 'Original': identity(raw), 'Stored': identity(stored)})
print(json.dumps({'SourceHead': C, 'ArchiveCommit': H, 'ChangedPaths': changed,
                  'Manifest': identity(manifest_raw), 'Records': records,
                  'OriginalBytes': sum(row['Original']['Bytes'] for row in records),
                  'StoredBytes': sum(row['Stored']['Bytes'] for row in records),
                  'NoSourceTestBenchmarkOrAlignmentChanges': True}, indent=2))
