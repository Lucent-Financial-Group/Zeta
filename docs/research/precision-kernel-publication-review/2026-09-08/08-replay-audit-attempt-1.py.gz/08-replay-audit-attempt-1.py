"""Compare already retained publication records; do not execute either producer."""
import gzip
import hashlib
import json
from pathlib import Path

P = Path('/Users/acehack/.zeta/agents/codex/Zeta-compiled-evidence-publication-20260907')
H = 'c1e6f0497afcc5078b03bfe8e797dc12e684cf58'
D = P / '.git/precision-publication-native-replay-1'
A = P / 'docs/research/precision-gate-kernels/2026-09-08/native-reference-replay'


def identity(raw):
    return {'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest()}


records = []
def read(path):
    raw = path.read_bytes()
    assert len(raw) <= 16 * 1024 * 1024
    records.append({'Path': str(path), **identity(raw)})
    return raw


actual_raw = read(D / 'stdout')
actual = json.loads(actual_raw)
historical_raw = gzip.decompress(read(A / '027-precision-kernel-native-replay-3-stdout.gz'))
historical = json.loads(historical_raw)
assert set(actual) == set(historical) == {'Schema', 'ReferenceSha256', 'Rows', 'Runtime'}
for key in ['Schema', 'ReferenceSha256', 'Rows']:
    assert actual[key] == historical[key]
assert len(actual['Rows']) == 24
assert sum(row['Outcome']['Kind'] == 'success' for row in actual['Rows']) == 17
assert sum(row['Outcome']['Kind'] == 'refused' for row in actual['Rows']) == 7
process = json.loads(read(D / 'process.json'))
assert process['Head'] == H and process['Exit'] == 0
assert read(D / 'stderr') == b''
assert len(process['AssembliesBefore']) == len(actual['Runtime']['Assemblies']) == 2
after = json.loads(read(D / 'assembly-before-observed-after.json'))
assert after['Observed'] == actual['Runtime']['Assemblies']
for before, observed in zip(process['AssembliesBefore'], actual['Runtime']['Assemblies'], strict=True):
    assert {k: before[k] for k in ['Path', 'Bytes', 'Sha256']} == {k: observed[k] for k in ['Path', 'Bytes', 'Sha256']}
    raw = read(P / before['Copy'])
    assert identity(raw) == {k: before[k] for k in ['Bytes', 'Sha256']}
    assert raw == read(Path(before['Path']))
for source, digest in process['Source'].items():
    assert identity(read(P / source))['Sha256'] == digest

comparison_raw = read(D / 'comparison.stdout')
assert comparison_raw == gzip.decompress(read(A / '015-precision-kernel-comparison-3-stdout.gz'))
comparison = json.loads(comparison_raw)
assert comparison['OrdinaryErrors'] == []
assert comparison['OrdinaryNumericSuccessRows'] == 16 and comparison['TypedRefusalRows'] == 7
assert len(comparison['Controls']) == 10 and all(row['Rejected'] is True and row['Errors'] for row in comparison['Controls'])
cp = json.loads(read(D / 'comparison.process.json'))
assert cp['Head'] == H and cp['Exit'] == 0
assert read(D / 'comparison.stderr') == b''
script = read(P / '.git/precision-publication-compare-1.py')
assert identity(script)['Sha256'] == cp['ScriptSha256']
old_script = gzip.decompress(read(A / '005-.git-precision-kernel-compare-3.py.gz'))
assert script == old_script.replace(b'.git/precision-kernel-native-replay-3/stdout', b'.git/precision-publication-native-replay-1/stdout')
failure = json.loads(read(D / 'capture-harness-failure-note.json'))
assert failure['OriginalStderrCaptured'] is False
assert failure['ReplayExit'] == failure['ComparisonExit'] == 0

F = P / '.git/precision-publication-formatter-1'
formatter = json.loads(read(F / 'process.json'))
assert formatter['Head'] == H and formatter['Exit'] == 0
read(F / 'start.json')
assert read(F / 'stdout') == b''
warnings = read(F / 'stderr').decode()
unsupported = warnings.count('Format currently supports only C# and Visual Basic projects.')
assert unsupported > 0

print(json.dumps({'PublicationHead': H, 'Records': records, 'NativeRowsEqualArchivedRoot': 24,
                  'OrdinaryNumericRows': 16, 'TypedRefusals': 7, 'SeparateEncodingRows': 1,
                  'ActualComparisonOutputEqualsArchivedRoot': True,
                  'ComparatorOnlyChangedNativeInputPath': True, 'RejectedOutputControls': 10,
                  'DirectAssembliesBeforeProducerAfterCopiesMatch': 2,
                  'NativeProcess': process, 'ComparisonProcess': cp,
                  'CaptureHarnessFailureTranscription': failure, 'Formatter': formatter,
                  'FormatterUnsupportedFSharpRows': unsupported,
                  'NoProducerComparatorOrNativeExecutionByReviewer': True}, indent=2))
