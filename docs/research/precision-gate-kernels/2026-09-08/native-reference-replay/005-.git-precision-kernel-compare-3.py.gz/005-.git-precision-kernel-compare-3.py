from pathlib import Path
from fractions import Fraction
from copy import deepcopy
import json, math, hashlib

REFERENCE = Path('/Users/acehack/.zeta/agents/codex/Zeta-relational-identity-20260906/docs/research/precision-gate-kernels-reference-validation/2026-09-08/reference-vectors.json')
NATIVE = Path('.git/precision-kernel-native-replay-3/stdout')
raw = REFERENCE.read_bytes()
assert len(raw) == 21985 and hashlib.sha256(raw).hexdigest() == 'ecab012f7084e17097594faabd2ee49ec7a76aa1da8a1fa4f2204ab8df841489'
def no_duplicates(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('duplicate key: ' + key)
        result[key] = value
    return result
reference = json.loads(raw, object_pairs_hook=no_duplicates, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON constant: ' + value)))
native = json.loads(NATIVE.read_bytes(), object_pairs_hook=no_duplicates, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON constant: ' + value)))
def same(ref, got, path, allow_zero_tolerance=False):
    if isinstance(ref, dict) and set(ref) != {'Num', 'Den'}:
        if not isinstance(got, dict) or set(ref) != set(got):
            return [path + ': field set differs']
        return sum((same(v, got[k], path + '.' + k, allow_zero_tolerance) for k, v in ref.items()), [])
    expected = float(Fraction(int(ref['Num']), int(ref['Den']))) if isinstance(ref, dict) else float(ref)
    if type(got) not in (int, float) or not math.isfinite(got):
        return [path + ': not a finite native numeric leaf']
    if expected == 0 and not allow_zero_tolerance and got != 0:
        return [path + ': exact zero changed']
    if abs(got - expected) > 1e-12 + 1e-12 * abs(expected):
        return [path + ': numerical difference']
    return []
FAILURES = {
 'gamma/improper': ('ImproperBelief', 'Gamma'),
 'gaussian/linear-improper': ('ImproperBelief', 'Gaussian'),
 'invalid/negative-variance': ('InvalidInput', 'Weight.Variance'),
 'invalid/nonpositive-gamma': ('InvalidInput', 'MeanBeta'),
 'invalid/proper-gaussian': ('ImproperBelief', 'Gaussian'),
 'invalid/objective-variance': ('InvalidInput', 'Candidate.Variance'),
 'shape/nonpositive': ('InvalidInput', 'Shape'),
}
def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)

def compare(candidate):
    errors = []
    if set(candidate) != {'Schema', 'ReferenceSha256', 'Rows', 'Runtime'}:
        return ['envelope fields differ']
    if candidate['Schema'] != 'zeta.precision-gate-kernels.native.v1' or candidate['ReferenceSha256'] != hashlib.sha256(raw).hexdigest():
        return ['schema/input identity differs']
    rows = candidate['Rows']
    if not isinstance(rows, list) or len(rows) != 24:
        return ['row count differs']
    if [r.get('Id') for r in rows] != [r['Id'] for r in reference['Rows']]:
        return ['ordered IDs differ']
    for ref, observed in zip(reference['Rows'], rows):
        name = ref['Id']
        if set(observed) != {'Id', 'Operation', 'Outcome'} or observed['Operation'] != ref['Operation']:
            errors.append(name + ': row fields or operation differ')
            continue
        ro, no = ref['Outcome'], observed['Outcome']
        if set(no) != set(ro) or no['Kind'] != ro['Kind']:
            errors.append(name + ': outcome kind/fields differ')
            continue
        if ro['Kind'] == 'refused':
            failure = no['Failure']
            if set(failure) != {'Code', 'Field', 'Message'} or (failure['Code'], failure['Field']) != FAILURES[name] or not isinstance(failure['Message'], str) or not failure['Message']:
                errors.append(name + ': wrong typed refusal')
            continue
        expected, got = deepcopy(ro['Value']), deepcopy(no['Value'])
        if name == 'shape/small':
            if set(got) != {'RequestedShape', 'RepresentedShape', 'Kernel'} or set(got['Kernel']) != {'LogPower', 'Rate'}:
                errors.append(name + ': encoding fields differ')
                continue
            if not (all(finite_number(value) for value in [got['RequestedShape'], got['RepresentedShape'], got['Kernel']['LogPower'], got['Kernel']['Rate']]) and got['Kernel']['LogPower'] == got['RequestedShape'] - 1 and got['RequestedShape'] == 1e-16 and got['Kernel']['Rate'] == 1 and got['RepresentedShape'] > 0 and got['RepresentedShape'] == got['Kernel']['LogPower'] + 1 and got['RepresentedShape'] != got['RequestedShape']):
                errors.append(name + ': encoding discrepancy not exposed')
            continue
        if ref['Operation'] == 'normal_precision_vmp':
            if 'ResidualSecondMoment' not in got or not finite_number(got['ResidualSecondMoment']) or got['ResidualSecondMoment'] != 2 * got['ToPrecision']['Rate']:
                errors.append(name + ': residual DTO relation differs')
            got.pop('ResidualSecondMoment', None)
        if ref['Operation'] == 'gamma_proper_moments':
            expected['RepresentedShape'] = expected.pop('Shape')
        errors.extend(same(expected, got, name, name == 'objective/stationary'))
    return errors
ordinary = compare(native)
controls = []
def control(name, mutate):
    value = deepcopy(native)
    mutate(value)
    errors = compare(value)
    controls.append({'Name': name, 'Rejected': bool(errors), 'Errors': errors})
def row(value, name):
    return next(x for x in value['Rows'] if x['Id'] == name)['Outcome']['Value']
control('double-half-rate', lambda v: row(v, 'soft/uncertain')['ToTau'].__setitem__('Rate', 86))
control('reverse-alpha-minus-one', lambda v: row(v, 'gamma/rate')['ToRate'].__setitem__('LogPower', 1))
control('wrong-deterministic-orientation', lambda v: next(x for x in v['Rows'] if x['Id'] == 'reverse/log')['Outcome'].__setitem__('Value', row(v, 'reverse/exp')))
control('negate-objective-gradient', lambda v: row(v, 'objective/general').__setitem__('DerivativeMean', -row(v, 'objective/general')['DerivativeMean']))
control('truncation', lambda v: v['Rows'].pop())
control('duplicate-id', lambda v: v['Rows'][1].__setitem__('Id', v['Rows'][0]['Id']))
control('extra-field', lambda v: row(v, 'soft/uncertain').__setitem__('Unexpected', 1))
control('boolean-shape-rate', lambda v: row(v, 'shape/small')['Kernel'].__setitem__('Rate', True))
control('nonfinite-shape-encoding', lambda v: (row(v, 'shape/small').__setitem__('RepresentedShape', math.inf), row(v, 'shape/small')['Kernel'].__setitem__('LogPower', math.inf)))
control('boolean-normal-residual', lambda v: row(v, 'normal/zero').__setitem__('ResidualSecondMoment', False))
report = {'OrdinaryErrors': ordinary, 'OrdinaryNumericSuccessRows': 16, 'TypedRefusalRows': 7, 'SeparateEncodingObservation': row(native, 'shape/small'), 'Controls': controls, 'Scope': 'fixed local numerical comparison; output mutations only; runtime custody checked separately'}
print(json.dumps(report, indent=2, allow_nan=False))
raise SystemExit(0 if not ordinary and all(x['Rejected'] for x in controls) else 2)
