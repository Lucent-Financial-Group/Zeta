Add checked scalar Gaussian/Gamma update kernels as a prerequisite for composable learned gates. The rules retain uncertain inputs, distinguish proper beliefs from signed site kernels, expose Gamma shape-rounding drift, and preserve the Exp/Log Jacobian distinction. They return explicit refusals for invalid or unrepresentable arithmetic.

An independent exact-rational/Decimal reference and a fixed 24-row native replay check the equations. The retained result has 16 ordinary numerical matches, seven expected typed refusals, and one separately exposed encoding discrepancy; all ten corrupted-output controls are rejected. This does not add a mixed scheduler, trained gate, optimizer or state-of-the-art result.

The indexed research also retains the reviewed finite-Q8 proposal and Otto/noninterference/oracle grounding, and records PR17027's verified main receipt and finite work-item completion. The moral-oracle explanation change remains separate.

Validation: all 18 full preflight checks pass at the publication source cut c1e6f0497afcc5078b03bfe8e797dc12e684cf58, including release build and full test suite. The unchanged kernel has 24 focused tests. Formatter verification exits zero but explicitly lacks F# support; F# lint passes separately. Publication replay retains actual two-assembly byte witnesses, not a transitive runtime closure. Original failures and the final capture-summary exception remain labeled in the evidence archives. Independent source, API, reference and replay reviews are indexed alongside their exact source cuts.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1Z63YMC087G0R003N5FH9X
Co-Authored-By: Codex <noreply@openai.com>
