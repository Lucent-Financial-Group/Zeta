from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
source = "20043d1408bfa3a515f5d59864ad858595044707"
base = root / "docs/research/hidden-switch-compiled-validation/2026-09-07/llvm-column-preparation"
base.mkdir()
pins = json.loads((root / ".git/hidden-switch-llvm-column-source-pins.json").read_text())
for pin in pins:
    raw = (root / pin["File"]).read_bytes()
    assert len(raw) == pin["Bytes"] and hashlib.sha256(raw).hexdigest().upper() == pin["Sha256"]
    assert subprocess.check_output(["git", "show", source + ":" + pin["File"]], cwd=root) == raw
paths = [root / (".git/hidden-switch-llvm-column-" + name) for name in [
    "tests-1.log", "combined-1.log", "ruff-1.log", "source-pins.json", "prior-check.json", "validation.json"]] + [Path(__file__).resolve()]
records = []
for path in paths:
    raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0)
    destination = base / (path.name + ".gz")
    with destination.open("xb") as stream:
        stream.write(stored)
    records.append({"File": destination.name, "OriginalLocalFile": str(path.relative_to(root)),
                    "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest().upper(),
                    "StoredBytes": len(stored), "StoredSha256": hashlib.sha256(stored).hexdigest().upper(), "Encoding": "gzip"})
with (base / "manifest.json").open("x") as stream:
    json.dump({"SourceCommit": source, "SourcePins": pins, "Scope": "actual retained-output parser fixture and pure column preparation; no new decoder process, dump or target",
               "Records": records}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"Records": len(records), "SourceCommit": source}))
