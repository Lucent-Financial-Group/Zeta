from pathlib import Path
import gzip,hashlib,json,sys
root=Path('.').resolve();sys.path.insert(0,str(root/'src/Research.FSharp.Cli'))
from capture_hidden_switch_dump import identity
attempt=root/'.git/hidden-switch-compiled-clrmd-mapped-attempt-1'
base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/clrmd-mapped-attempt-1';base.mkdir()
inputs=json.loads((attempt/'inputs.json').read_text()); manifest=json.loads((attempt/'helper-input.json').read_text()); output=json.loads((attempt/'helper-output.json').read_text()); outcome=json.loads((attempt/'outcome.json').read_text())
assert outcome['Complete'] and output['Complete'] and outcome['HelperProcess']['ExitCode']==0
assert len(output['Methods'])==len(manifest['Methods'])==130
for expected,observed in zip(manifest['Methods'],output['Methods'],strict=True):
 assert observed['Role']==expected['Role'] and observed['Token']==expected['Token'] and observed['DeclaringType']==expected['DeclaringType'] and observed['Name']==expected['Name']
 assert observed['Query']==observed['NativeCode']==observed['HotStart']==expected['Address'] and observed['HotSize']==expected['Bytes'] and observed['ColdStart']==observed['ColdSize']==0
 assert observed['ModuleName']==manifest['Module']['Original']['File']
 physical=json.loads((attempt/f"physical-{expected['Role']}.json").read_text())
 assert physical['CompilerMatchesPhysical'] and physical['Body']['Sha256']==expected['BodySha256'] and physical['Body']['Bytes']==expected['Bytes']
changed=[p['File'] for p in inputs['HelperSourcesModulesAndHost'] if identity(Path(p['File']))!=p]
for row in inputs['HelperCustody']:
 for side in ['Original','Copy']:
  if identity(Path(row[side]['File']))!=row[side]:changed.append(row[side]['File'])
assert not changed
journal=[json.loads(line) for line in (attempt/'helper-output.json.jsonl').read_text().splitlines()]
selected=[r for r in journal if r['Kind'] in ['dyld-count-before','dyld-count-after','loaded-dac-path-file','managed-load-snapshot','dump-runtime','target-settings']]
result={'ExecutionSource':inputs['SourceCommit'],'ImplementationSource':'af90bfc9e95fbdb8246c438da26e30a727bcbb5f','Review':'619e33121194fd047e7b3fbd3a4d308b3459cc24',
 'ComparedMethods':130,'ComparedBytes':sum(x['Bytes'] for x in manifest['Methods']),'AllColdZero':True,'AllPhysicalCompilerCurrentExtentsMatch':True,
 'HelperPins':len(inputs['HelperSourcesModulesAndHost']),'HelperCustodyFiles':len(inputs['HelperCustody']),'CurrentHelperPinsAndCopiesUnchanged':not changed,
 'ActualLocatorRequests':output['LocatorRequests'],'JournalRows':len(journal),'SelectedObservations':selected,
 'Output':identity(attempt/'helper-output.json'),'Journal':identity(attempt/'helper-output.json.jsonl'),'Outcome':outcome,
 'LiteralReads':0,'ExtraCompilerBlockReads':0,'UnpreparedReflectionRows':9,'UnmappedCompilerBlocks':9,
 'LocalOnlyDump':manifest['Dump'],'DumpMemoryPublication':False,
 'Limits':'Full-file hash and ClrMD/DAC internal metadata reads occur; explicit physical driver reads only reviewed130chains. Native loaded-image path/file correspondence is not loaded-memory equivalence; local PE MVID association is not dump-derived MVID. Full closure/runtime admission false.'}
summary=root/'.git/hidden-switch-clrmd-mapped-attempt-1-results.json';summary.write_text(json.dumps(result,indent=2)+'\n')
paths=sorted(p for p in attempt.iterdir() if p.is_file())+[root/'.git/hidden-switch-clrmd-mapped-attempt-1-invocation.json',root/'.git/hidden-switch-clrmd-mapped-attempt-1.log',summary,Path(__file__).resolve()]
records=[]
for p in paths:
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);dest=base/(p.name+'.gz');dest.write_bytes(stored)
 records.append({'File':dest.name,'OriginalLocalFile':str(p.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
(base/'manifest.json').write_text(json.dumps({'ExecutionSource':inputs['SourceCommit'],'ImplementationSource':result['ImplementationSource'],'Scope':'actual finite130extent correspondence; raw dump and binary copies local-only; full admission false','Records':records},indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['ComparedMethods','ComparedBytes','HelperPins','HelperCustodyFiles','JournalRows','Output','Journal','SelectedObservations']},indent=2));print('RECORDS',len(records))
