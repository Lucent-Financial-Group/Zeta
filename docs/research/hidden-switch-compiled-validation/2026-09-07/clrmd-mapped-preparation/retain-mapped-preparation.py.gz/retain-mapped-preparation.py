from pathlib import Path
import gzip, hashlib, json, subprocess, xml.etree.ElementTree as ET
root=Path('.').resolve(); base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/clrmd-mapped-preparation'
base.mkdir()
def pin(p):
 raw=p.read_bytes(); return {'File':str(p.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()}
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
files=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',source],text=True).splitlines()
trx=root/'tests/Tests.FSharp/TestResults/hidden-switch-mapped-focused-1.trx'
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
rows=[{'Name':r.attrib['testName'],'Outcome':r.attrib['outcome']} for r in ET.parse(trx).findall('.//t:UnitTestResult',ns)]
summary={'SourceCommit':source,'SourcePins':[pin(root/f) for f in files],
 'ValidationSourceTiming':'native builds/tests ran on the uncommitted source subsequently committed; final driver custody/diagnostic-only corrections were reviewed and final Python suite ran at this source head',
 'Rows':rows,'NativePassed':sum(r['Outcome']=='Passed' for r in rows),'NativeFailed':sum(r['Outcome']!='Passed' for r in rows),
 'OutputPins':[pin(root/'src/Research.FSharp.Cli/MetadataProbe/bin/Release/net10.0'/n) for n in ['Zeta.Research.HiddenSwitchMetadata.dll','Zeta.Research.HiddenSwitchMetadata.deps.json','Zeta.Research.HiddenSwitchMetadata.runtimeconfig.json']],
 'InitialPythonSetup':'Initial append used a repository-relative destination while cwd was already src/Research.FSharp.Cli and the shell reported no such file. The following discovery ran only the four pre-existing tests; its log is retained as that narrower result. No new tests existed until the corrected append.',
 'FullRuntimeAdmission':False,'ExpandedQueryExecuted':False}
(root/'.git/hidden-switch-mapped-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=sorted(root.glob('.git/hidden-switch-mapped-*.log'))+[root/'.git/hidden-switch-mapped-capture-recheck-1.json',root/'.git/hidden-switch-mapped-validation.json',trx,Path(__file__).resolve()]
records=[]
for p in paths:
 raw=p.read_bytes(); stored=gzip.compress(raw,mtime=0); dest=base/(p.name+'.gz');dest.write_bytes(stored)
 records.append({'File':dest.name,'OriginalLocalFile':str(p.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
(base/'manifest.json').write_text(json.dumps({'SourceCommit':source,'Scope':'bounded mapped130 preparation only; no new dump or metadata query','Records':records},indent=2)+'\n')
print(json.dumps({'Records':len(records),'NativeRows':len(rows),'NativePassed':summary['NativePassed'],'SourceCommit':source}))
