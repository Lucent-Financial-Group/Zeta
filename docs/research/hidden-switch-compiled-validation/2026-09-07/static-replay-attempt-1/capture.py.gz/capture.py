from __future__ import annotations
import dataclasses, hashlib, json, subprocess, sys
from pathlib import Path
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_bindings as bindings
from zeta_interp import hidden_switch_compiled_conformance as c
from zeta_interp import hidden_switch_compiled_record_encoding as encoding
from zeta_interp import hidden_switch_compiled_static_fixtures as fixtures
from zeta_interp import hidden_switch_compiled_static_replay as replay

base=Path(__file__).resolve().parent
root=base.parents[1]
artifacts=[]
def keep(name, value):
    result=encoding.encode_public_result(value,maximum_bytes=32*1024*1024)
    assert isinstance(result,a.Admitted),result
    raw=result.value
    with (base/name).open('xb') as target:target.write(raw)
    artifacts.append({'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})

context=bindings.BindingContext(a.PROTOCOL_SHA256,'1'*40,'2'*64,'3'*64)
specs={row.CaseId:row for row in c.case_specs()}
rows=[];producer_calls=0
for case_index,case_id in enumerate(fixtures.STATIC_CASE_IDS):
    prepared=fixtures.prepare_static_case(case_id,context=context)
    keep(f'producer-preparation-{case_index:02d}.json',prepared)
    assert isinstance(prepared,a.Admitted),prepared
    fixed=prepared.value;calls=[]
    for call_index,spec in enumerate(specs[case_id].Calls):
        actual=fixtures.execute_static_call(case_id,call_index,fixed.Inputs,fixed.SupportingArtifacts)
        producer_calls+=1
        # Actual return is preserved before even canonical result encoding below.
        keep(f'producer-call-{producer_calls-1:02d}.json',c.CallResult(spec.Operation,spec.InputRoles,actual))
        encoded=encoding.encode_public_result(actual,maximum_bytes=replay.MAX_RESULT_BYTES)
        assert isinstance(encoded,a.Admitted),encoded
        calls.append(replay.RecordedCall(spec.Operation,spec.InputRoles,encoded.value))
    rows.append(replay.RecordedCase(case_id,fixed.Inputs,fixed.SupportingArtifacts,tuple(calls)))
records=tuple(rows)
keep('recorded-fixtures.json',records)
result=replay.replay_static_cases(records,context=context)
keep('complete-replay.json',result)
assert isinstance(result,replay.StaticReplaySucceeded) and result.Counts==replay.Counts(32,36,36,36,32)

last=records[-1]
malformed_calls=(*last.Calls[:-1],dataclasses.replace(last.Calls[-1],ResultRaw=b'{"x":0,"x":0}'))
malformed=(*records[:-1],dataclasses.replace(last,Calls=malformed_calls))
failed=replay.replay_static_cases(malformed,context=context)
keep('late-malformed-replay.json',failed)
assert isinstance(failed,replay.StaticReplayFailed) and failed.Counts==replay.Counts(32,36,36,35,31)
assert failed.Failure.code=='static-recorded-json' and failed.Calls[-1].Actual is not None
assert failed.Calls[-1].Actual.Result==a.Admitted({'Numerator':9007199254740993,'Denominator':18014398509481984,'AtMostHalf':False})
missing=(*records[:-1],dataclasses.replace(last,Calls=last.Calls[:-1]))
missing_result=replay.replay_static_cases(missing,context=context)
keep('late-missing-call-replay.json',missing_result)
assert isinstance(missing_result,replay.StaticReplayFailed) and missing_result.Counts==replay.Counts(32,35,35,35,31)
modules=[]
for name,module in sorted(sys.modules.items()):
    if name.startswith('zeta_interp.hidden_switch'):
        path=Path(module.__file__).resolve();raw=path.read_bytes()
        modules.append({'Module':name,'File':path.relative_to(root).as_posix(),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
validation={'Schema':'zeta.hidden-switch.compiled.static-replay-implementation-validation.v1','SourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'PythonExecutable':sys.executable,'PythonVersion':sys.version,'Context':dataclasses.asdict(context),'ContextScope':'synthetic fixed caller context; not a source or runtime admission','ProducerCalls':producer_calls,'ReplayCalls':[dataclasses.asdict(result.Counts),dataclasses.asdict(failed.Counts),dataclasses.asdict(missing_result.Counts)],'CapturedPublicResultFiles':artifacts,'ObservedLoadedSources':modules,'Scope':'32 fixed static cases only; producer fixtures and independent actual shared API replay','NativeLaunches':0,'PolicyCalls':0,'RegisteredSourceGeneration':False,'ModuleRuntimeAdmission':'not performed; loaded module paths/current bytes are observations','OutsideReplayRetention':'This capture harness writes its own exclusive evidence files. The replay API itself has no filesystem effects.'}
with (base/'validation.json').open('x') as output:json.dump(validation,output,indent=2);output.write('\n')
print(json.dumps({'ProducerCalls':producer_calls,'ReplayCalls':[36,36,35],'CaseCount':32,'Captures':len(artifacts),'LoadedTaskModules':len(modules)}))
