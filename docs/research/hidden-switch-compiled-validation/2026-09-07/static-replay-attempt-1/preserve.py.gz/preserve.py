from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();source=root/'.git/compiled-static-replay-development';dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/static-replay-attempt-1';dest.mkdir(parents=True,exist_ok=False)
validation=json.loads((source/'validation.json').read_bytes());pin=validation['SourceCommit'];assert pin=='dc42bd64b302981e9b9a093db8b02183b52e5d05'
manifest={'SourceCommit':pin,'Scope':'32 source-fixed static cases and 36 actual shared API call slots; no full outer/runtime admission','SourceFiles':[],'Artifacts':[],'NativeLaunches':0,'PolicyCalls':0,'RegisteredSourceGeneration':False}
for path in [row['File'] for row in validation['ObservedLoadedSources']]+['src/Interp.Python/tests/test_hidden_switch_compiled_static_replay.py']:
 raw=subprocess.check_output(['git','show',pin+':'+path]);assert raw==(root/path).read_bytes();manifest['SourceFiles'].append({'File':path,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
for path in sorted(source.iterdir()):
 assert path.is_file() and not path.is_symlink()
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);name=path.name+'.gz'
 with (dest/name).open('xb') as output:output.write(packed)
 assert gzip.decompress(packed)==raw
 manifest['Artifacts'].append({'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Encoding':'gzip','StoredBytes':len(packed),'StoredSha256':hashlib.sha256(packed).hexdigest().upper()})
with (dest/'manifest.json').open('x') as output:json.dump(manifest,output,indent=2);output.write('\n')
print(json.dumps({'Artifacts':len(manifest['Artifacts']),'SourceFiles':len(manifest['SourceFiles']),'RawBytes':sum(row['Bytes'] for row in manifest['Artifacts'])}))
