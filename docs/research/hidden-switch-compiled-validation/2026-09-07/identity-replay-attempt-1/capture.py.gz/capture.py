from __future__ import annotations
import dataclasses,hashlib,json,subprocess,sys
from pathlib import Path
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_conformance as c
from zeta_interp import hidden_switch_compiled_identity_fixtures as fixtures
from zeta_interp import hidden_switch_compiled_identity_replay as replay
from zeta_interp import hidden_switch_compiled_record_encoding as encoding

base=Path(__file__).resolve().parent
root=base.parents[1]
owned=base/'capture-owned'
owned.mkdir(exist_ok=False)
producer=owned/'producer';producer.mkdir()
replayed=owned/'replay';replayed.mkdir()
sources=tuple(fixtures.FixtureSource(name,fixtures.PACKAGE_PATH+'/'+name.rsplit('.',1)[1]+'.py',(root/'src/Interp.Python/zeta_interp'/(name.rsplit('.',1)[1]+'.py')).read_bytes()) for name in (fixtures.COLLECTOR,fixtures.IEEE))
artifacts=[]
def keep(name,value):
    encoded=encoding.encode_public_result(value,maximum_bytes=32*1024*1024)
    assert isinstance(encoded,a.Admitted),encoded
    raw=encoded.value
    with (base/name).open('xb') as target:target.write(raw)
    artifacts.append({'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})

records=[];roots=[]
for index,case in enumerate(fixtures.CASE_IDS):
    target=producer/f'case-{index:02d}'
    actual=fixtures.run_identity_fixture(case,target,python_sources=sources if case in fixtures.PYTHON_CASES else ())
    keep(f'producer-fixture-{index:02d}.json',actual)
    assert isinstance(actual,fixtures.FixtureReady),actual
    encoded=encoding.encode_public_result(actual.Call.Result,maximum_bytes=replay.MAX_RESULT_BYTES)
    assert isinstance(encoded,a.Admitted),encoded
    children=tuple(c.NamedInput(role,(target/file).read_bytes()) for role,file in zip(replay.CHILD_ROLES,replay.CHILD_FILES,strict=True)) if case in fixtures.PYTHON_CASES else ()
    records.append(replay.RecordedIdentityCase(case,actual.Inputs,actual.Call.Operation,actual.Call.InputRoles,encoded.value,children))
    roots.append(replay.ProducerRoot(case,str(target)))
records=tuple(records);roots=tuple(roots)
keep('recorded-fixtures.json',records)
result=replay.replay_identity_cases(records,replayed,producer_roots=roots,python_sources=sources)
keep('complete-replay.json',result)
assert isinstance(result,replay.IdentityReplaySucceeded),result
assert result.Counts==replay.Counts(15,15,15,15)
for index,row in enumerate(result.Cases):
    assert isinstance(row.Actual.Returned,fixtures.FixtureReady)
    keep(f'replayed-fixture-{index:02d}.json',row.Actual.Returned)

modules=[]
for name,module in sorted(sys.modules.items()):
    if name.startswith('zeta_interp.hidden_switch'):
        path=Path(module.__file__).resolve();raw=path.read_bytes()
        modules.append({'Module':name,'File':path.relative_to(root).as_posix(),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
validation={'Schema':'zeta.hidden-switch.compiled.identity-replay-implementation-validation.v1','SourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'PythonExecutable':sys.executable,'PythonVersion':sys.version,'CaseIds':list(fixtures.CASE_IDS),'ProducerFixtureReturns':15,'ProducerCompletedOperations':15,'ReplayCounts':dataclasses.asdict(result.Counts),'CapturedPublicResultFiles':artifacts,'ObservedLoadedSources':modules,'SuppliedChildSources':[{'Module':item.Module,'File':item.RelativePath,'Bytes':len(item.Raw),'Sha256':hashlib.sha256(item.Raw).hexdigest().upper()} for item in sources],'ProducerRoots':[dataclasses.asdict(item) for item in roots],'OwnedRoot':str(owned),'Scope':'actual fixed owned Git/Python implementation fixtures and fresh replay only','NativeLaunches':0,'PolicyCalls':0,'RegisteredSourceGeneration':False,'ModuleRuntimeAdmission':'not performed; current source observations and exact fixture result comparison only','Retention':'Actual fixture returns are retained before the next case. This harness writes external evidence files; each fixture keeps its complete owned tree independently.'}
with (base/'validation.json').open('x') as output:json.dump(validation,output,indent=2);output.write('\n')
print(json.dumps({'ProducerReturns':15,'ReplayCounts':dataclasses.asdict(result.Counts),'Captures':len(artifacts),'LoadedTaskModules':len(modules)}))
