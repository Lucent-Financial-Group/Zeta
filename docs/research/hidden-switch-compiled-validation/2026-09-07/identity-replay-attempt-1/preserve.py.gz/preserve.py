from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,tarfile
root=Path.cwd();source=root/'.git/compiled-identity-replay-development'
destination=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/identity-replay-attempt-1'
destination.mkdir(parents=True,exist_ok=False)
validation=json.loads((source/'validation.json').read_bytes())
pin=validation['SourceCommit'];assert pin=='d3bd541e1d043e199c4b54b5390450028473c1cd'
manifest={'SourceCommit':pin,'Scope':'fixed owned source/Python fixture replay implementation validation; no complete coordinator/runtime admission','SourceFiles':[],'Artifacts':[],'OwnedTrees':[],'NativeLaunches':0,'PolicyCalls':0,'RegisteredSourceGeneration':False}
def identity(path):
 digest=hashlib.sha256();length=0
 with path.open('rb') as stream:
  while chunk:=stream.read(1024*1024):digest.update(chunk);length+=len(chunk)
 return length,digest.hexdigest().upper()
def artifact(name,raw):
 packed=gzip.compress(raw,mtime=0)
 with (destination/(name+'.gz')).open('xb') as output:output.write(packed)
 assert gzip.decompress(packed)==raw
 manifest['Artifacts'].append({'File':name+'.gz','Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Encoding':'gzip','StoredBytes':len(packed),'StoredSha256':hashlib.sha256(packed).hexdigest().upper()})
for path in sorted({row['File'] for row in validation['ObservedLoadedSources']}|{row['File'] for row in validation['SuppliedChildSources']}|{'src/Interp.Python/tests/test_hidden_switch_compiled_identity_replay.py'}):
 raw=subprocess.check_output(['git','show',pin+':'+path]);assert raw==(root/path).read_bytes()
 manifest['SourceFiles'].append({'File':path,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
for owned in sorted(path for path in source.iterdir() if path.is_dir()):
 entries=[]
 for directory,dirs,files in os.walk(owned,followlinks=False):
  for name in sorted(dirs+files):
   path=Path(directory)/name;metadata=path.lstat();relative=path.relative_to(owned).as_posix()
   if stat.S_ISLNK(metadata.st_mode):entries.append({'File':relative,'Kind':'symlink','Target':os.readlink(path),'Mode':metadata.st_mode})
   elif stat.S_ISDIR(metadata.st_mode):entries.append({'File':relative,'Kind':'directory','Mode':metadata.st_mode})
   else:
    assert stat.S_ISREG(metadata.st_mode)
    length,digest=identity(path);assert length==metadata.st_size
    entries.append({'File':relative,'Kind':'regular','Mode':metadata.st_mode,'Bytes':length,'Sha256':digest})
 entries.sort(key=lambda row:row['File'])
 archive_name=owned.name+'.tar.gz';archive_path=destination/archive_name
 class HashWriter:
  def __init__(self,target):self.target=target;self.digest=hashlib.sha256();self.length=0
  def write(self,raw):self.digest.update(raw);self.length+=len(raw);return self.target.write(raw)
 with archive_path.open('xb') as file:
  with gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0) as compressed:
   writer=HashWriter(compressed)
   with tarfile.open(fileobj=writer,mode='w|') as archive:
    for row in entries:
     path=owned/row['File'];info=archive.gettarinfo(str(path),arcname=row['File'])
     if row['Kind']=='regular':
      with path.open('rb') as stream:archive.addfile(info,stream)
     else:archive.addfile(info)
 stored_length,stored_digest=identity(archive_path)
 raw_digest=hashlib.sha256();raw_length=0
 with gzip.open(archive_path,'rb') as stream:
  while chunk:=stream.read(1024*1024):raw_digest.update(chunk);raw_length+=len(chunk)
 assert raw_length==writer.length and raw_digest.hexdigest().upper()==writer.digest.hexdigest().upper()
 actual=[]
 with tarfile.open(archive_path,'r:gz') as archive:
  for member in archive:
   if member.isfile():
    stream=archive.extractfile(member);assert stream is not None
    digest=hashlib.sha256();length=0
    while chunk:=stream.read(1024*1024):digest.update(chunk);length+=len(chunk)
    actual.append((member.name,'regular',length,digest.hexdigest().upper()))
   elif member.issym():actual.append((member.name,'symlink',member.linkname))
   else:assert member.isdir();actual.append((member.name,'directory'))
 expected=[(row['File'],'regular',row['Bytes'],row['Sha256']) if row['Kind']=='regular' else (row['File'],'symlink',row['Target']) if row['Kind']=='symlink' else (row['File'],'directory') for row in entries]
 assert actual==expected
 manifest['Artifacts'].append({'File':archive_name,'Bytes':raw_length,'Sha256':raw_digest.hexdigest().upper(),'Encoding':'gzip','StoredBytes':stored_length,'StoredSha256':stored_digest})
 inventory={'OriginalRoot':str(owned),'Entries':entries}
 artifact(owned.name+'-inventory.json',json.dumps(inventory,indent=2).encode()+b'\n')
 manifest['OwnedTrees'].append({'OriginalRoot':str(owned),'Archive':archive_name,'Inventory':owned.name+'-inventory.json.gz','RegularFiles':sum(row['Kind']=='regular' for row in entries),'FileBytes':sum(row.get('Bytes',0) for row in entries),'Symlinks':sum(row['Kind']=='symlink' for row in entries),'Directories':sum(row['Kind']=='directory' for row in entries)})
for path in sorted(source.iterdir()):
 if path.is_file() and not path.is_symlink():artifact(path.name,path.read_bytes())
with (destination/'manifest.json').open('x') as output:json.dump(manifest,output,indent=2);output.write('\n')
print(json.dumps({'Artifacts':len(manifest['Artifacts']),'SourceFiles':len(manifest['SourceFiles']),'OwnedTrees':manifest['OwnedTrees'],'OriginalArtifactBytes':sum(row['Bytes'] for row in manifest['Artifacts'])}))
