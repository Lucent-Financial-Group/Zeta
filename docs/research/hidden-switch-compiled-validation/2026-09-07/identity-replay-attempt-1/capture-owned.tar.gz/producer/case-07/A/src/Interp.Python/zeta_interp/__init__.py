"""Tiny owned fixture package; no production activation imports."""
import os
if os.environ["ZETA_IDENTITY_CASE"] == "python/foreign-entry":
    __path__ = [os.environ["ZETA_IDENTITY_B_PACKAGE"]]
