from pathlib import Path
import contextlib
import json
import os
import signal
import subprocess
import sys
sys.path.insert(0, str(Path('src/Research.FSharp.Cli').resolve()))
from capture_hidden_switch_dump import custody_copy, identity, utc, write
from probe_hidden_switch_metadata import wait_helper, cleanup_owned
root=Path('.').resolve()
attempt=root/'.git/hidden-switch-clrmd-startup-attempt-1'
os.mkdir(attempt)
helper=root/'src/Research.FSharp.Cli/MetadataProbe/bin/Release/net10.0/Zeta.Research.HiddenSwitchMetadata.dll'
host=Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet')
process=out=err=None
result={'Kind':'metadata-helper-no-argument-startup','Complete':False,'Failure':None,'RuntimeAdmitted':False,'BodyResolved':False,'ClosureAdmitted':False,'DumpQueries':0}
stage='start'
try:
 write(attempt/'start.json',{**result,'StartedAtUtc':utc(),'TimeoutSeconds':10,'OutputPolledBytes':65536,'SourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()})
 files=sorted(helper.parent.rglob('*.dll'))+[helper.with_suffix('.deps.json'),helper.with_suffix('.runtimeconfig.json'),helper.parent/'dependencies.json']
 if len(files)!=31:raise ValueError('expected exactly31 repaired helper modules/configs')
 copies=[]
 for index,source in enumerate(files):
  destination=attempt/'helper-files'/source.relative_to(helper.parent)
  destination.parent.mkdir(parents=True,exist_ok=True)
  row=custody_copy(source,destination);copies.append(row);write(attempt/f'custody-{index:02d}.json',row)
 pins=[identity(p) for p in files+[host,Path(__file__).resolve()]]
 args=[str(host),str(helper)]
 write(attempt/'invocation.json',{'Arguments':args,'Pins':pins,'Copies':copies,'Meaning':'no input path or dump parameter is supplied; actual executable dependency startup only'})
 stage='startup'
 out=(attempt/'helper.stdout.log').open('xb');err=(attempt/'helper.stderr.log').open('xb')
 process=subprocess.Popen(args,cwd=attempt,stdout=out,stderr=err,start_new_session=True)
 write(attempt/'process.json',{'ProcessId':process.pid,'StartedAtUtc':utc()})
 wait_helper(process,attempt,seconds=10,limit=65536)
 actual=(attempt/'helper.stderr.log').read_bytes()
 if process.returncode!=2 or (attempt/'helper.stdout.log').stat().st_size!=0 or actual!=b'requires input-manifest and exclusive output path; no study execution\n':raise ValueError('startup did not reach the exact typed usage path')
 if any(identity(Path(p['File']))!=p for p in pins):raise ValueError('startup inputs changed')
 if any(identity(Path(row['Copy']['File']))!=row['Copy'] for row in copies):raise ValueError('startup copy changed')
 result.update(Complete=True,InputsUnchanged=True,CopiesUnchanged=True)
except Exception as error:
 result['Failure']={'Stage':stage,'Code':type(error).__name__,'Detail':str(error)}
finally:
 result['CleanupFailures']=cleanup_owned(process,[('stdout',out),('stderr',err)])
 result['Complete']=result['Complete'] and not result['CleanupFailures']
 result['Process']=None if process is None else {'ProcessId':process.pid,'ExitCode':process.poll()}
 result['FinishedAtUtc']=utc()
 write(attempt/'outcome.json',result)
 print(json.dumps(result))
raise SystemExit(0 if result['Complete'] else 2)
