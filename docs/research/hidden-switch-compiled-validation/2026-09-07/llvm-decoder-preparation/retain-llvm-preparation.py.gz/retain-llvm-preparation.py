from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('.').resolve();base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/llvm-decoder-preparation';base.mkdir()
paths=sorted((root/'.git/hidden-switch-llvm-decoder-preparation').iterdir())+sorted(root.glob('.git/hidden-switch-llvm-decoder-*.log'))+[Path(__file__).resolve()]
records=[]
for p in paths:
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);dest=base/(p.name+'.gz');dest.write_bytes(stored)
 records.append({'File':dest.name,'OriginalLocalFile':str(p.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
sourcefiles=['src/Research.FSharp.Cli/'+name for name in ['decode_hidden_switch_methods.py','test_decode_hidden_switch_methods.py']]
sourcepins=[]
for file in sourcefiles:
 raw=(root/file).read_bytes();sourcepins.append({'File':file,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
(base/'manifest.json').write_text(json.dumps({'SourceCommit':source,'SourcePins':sourcepins,'Scope':'synthetic decoder grammar and pure fixtures only; no candidate/dump/target execution','Records':records},indent=2)+'\n')
print(json.dumps({'Records':len(records),'Source':source,'Pins':sourcepins}))
