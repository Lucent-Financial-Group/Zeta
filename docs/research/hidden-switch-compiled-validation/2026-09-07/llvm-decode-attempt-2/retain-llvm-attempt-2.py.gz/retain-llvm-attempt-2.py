from pathlib import Path
import gzip
import hashlib
import json
import re

root = Path(__file__).resolve().parents[1]
attempt = root / ".git/hidden-switch-llvm-decode-attempt-2"
base = root / "docs/research/hidden-switch-compiled-validation/2026-09-07/llvm-decode-attempt-2"
base.mkdir()
outcome = json.loads((attempt / "outcome.json").read_text())
lines = (attempt / "helper.stdout.log").read_text().splitlines()
encoding_lines = [line for line in lines if "; encoding: [" in line]
comments = [line for line in lines if line.lstrip().startswith(";")]
assert len(lines) == 9516 and len(encoding_lines) == 8665 and len(comments) == 851
assert all(re.fullmatch(r" {40}; =0x[0-9a-f]+", line) for line in comments)
assert (attempt / "helper.stderr.log").read_bytes() == b""
assert (attempt / "decoder.input").read_bytes() == (root / ".git/hidden-switch-llvm-decode-attempt-1/decoder.input").read_bytes()
assert outcome["Failure"]["Detail"] == "word 22 has an unsupported standalone comment association"
assert len(outcome["CompletedMethods"]) == 2 and len(outcome["ActiveDecodedPrefix"]) == 12
summary = {"SourceCommit": "4a570eaf3ee2d5dccef07b5eeea229a363cd7365", "ExecutionHead": "386783454f0f11328e3ab39dba66a6081dfaf1d8",
           "Outcome": outcome, "RequestedMethods": 130, "InputWords": 8665, "AtomicInputUnchangedFromAttempt1": True,
           "StderrBytes": 0, "RawStdoutLines": len(lines), "RawEncodingLines": len(encoding_lines), "RawCommentLines": len(comments),
           "CommentLeadingSpaces": 40, "FirstFailedInstructionTextLine": 23, "FirstFailedCommentTextLine": 24,
           "FirstFailedInstructionRaw": lines[22], "FirstFailedCommentRaw": lines[23],
           "AdmittedCompleteMethods": 2, "AdmittedActiveWords": 12,
           "Interpretation": "Raw line-shape inspection only; complete word admission refused at the first indented comment. No decoder rerun, dump or target."}
summary_path = root / ".git/hidden-switch-llvm-decode-attempt-2-results.json"
summary_path.write_text(json.dumps(summary, indent=2) + "\n")
paths = sorted(attempt.iterdir()) + [root / ".git/hidden-switch-llvm-decode-attempt-2-invocation.json",
                                   root / ".git/hidden-switch-llvm-decode-attempt-2.log", summary_path, Path(__file__).resolve()]
records = []
for path in paths:
    raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0)
    destination = base / (path.name + ".gz")
    with destination.open("xb") as stream:
        stream.write(stored)
    records.append({"File": destination.name, "OriginalLocalFile": str(path.relative_to(root)),
                    "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest().upper(),
                    "StoredBytes": len(stored), "StoredSha256": hashlib.sha256(stored).hexdigest().upper(), "Encoding": "gzip"})
with (base / "manifest.json").open("x") as stream:
    json.dump({"SourceCommit": summary["SourceCommit"], "ExecutionHead": summary["ExecutionHead"],
               "Scope": "second actual decoder attempt; successful LLVM process but parser refusal with retained22word prefix; no full admission",
               "Records": records}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"Records": len(records), "RawEncodingLines": len(encoding_lines), "RawCommentLines": len(comments)}))
