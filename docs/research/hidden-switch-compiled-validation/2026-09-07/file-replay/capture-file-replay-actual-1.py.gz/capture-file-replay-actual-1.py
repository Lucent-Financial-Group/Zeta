from pathlib import Path
import datetime,hashlib,json,subprocess,sys
root=Path.cwd();sys.path.insert(0,str(root/'src/Interp.Python'))
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_conformance as c
from zeta_interp import hidden_switch_compiled_file_fixtures as f
from zeta_interp import hidden_switch_compiled_file_replay as r
from zeta_interp import hidden_switch_compiled_record_encoding as e
from zeta_interp import hidden_switch_compiled_record_store as store
from zeta_interp import hidden_switch_compiled_storage as storage
source='e6238f8acc89c4d619c6631f0cb0111aa9258c20'
pins=[]
for name in subprocess.check_output(['git','ls-files','src/Interp.Python'],text=True).splitlines():
 if name.endswith(('.py','.toml','.lock')):
  raw=(root/name).read_bytes();assert raw==subprocess.check_output(['git','show',source+':'+name]);pins.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
opened=store.open_store(root/'.git','compiled-file-replay-actual-1');assert isinstance(opened,store.Opened),opened
handle=opened.Store;attempt=root/'.git'/opened.Snapshot.AttemptName
journal=[];failure=None;final=None;producer_calls=replay_calls=matched_cases=0
return_directory=root/'.git/compiled-file-replay-actual-1-store-returns';return_directory.mkdir(exist_ok=False)
external_bytes=0

def keep(role,value,*,raw=False):
 observed=store.append_bytes(handle,role,value) if raw else store.append_result(handle,role,value)
 global external_bytes
 receipt=e.encode_public_result(observed,maximum_bytes=4*1024*1024)
 if not isinstance(receipt,a.Admitted):raise RuntimeError('store return receipt encoding refused: '+repr(receipt))
 if len(receipt.value)>64*1024*1024-external_bytes:raise RuntimeError('separate store-return receipt budget exceeded')
 external_bytes+=len(receipt.value)
 name=f'{len(journal):03d}.json'
 with (return_directory/name).open('xb') as out:out.write(receipt.value)
 journal.append(dict(Role=role,ActualStoreReturn=dict(File=name,Bytes=len(receipt.value),Sha256=hashlib.sha256(receipt.value).hexdigest().upper())))
 if not isinstance(observed,store.Stored):raise RuntimeError('actual record-store refusal; full return retained')
 return observed

def encoded(observed):
 call=observed.Attempt.Encoding
 assert call is not None and call.Raised is None and isinstance(call.Returned,a.Admitted) and type(call.Returned.value) is bytes
 return call.Returned.value

started=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 keep('capture-harness',Path(__file__).read_bytes(),raw=True)
 keep('source-pins',dict(SourceCommit=source,SourceFiles=pins,StartedAt=started,Scope='seven-file-fixture-producers-and-fresh-replay-only'))
 keep('store-open-snapshot',opened.Snapshot)
 for directory in ['producer','replay']:
  actual=storage.create_directory(attempt,directory);keep(directory+'-directory',actual);assert isinstance(actual,a.Admitted)
 records=[]
 specs={spec.CaseId:spec for spec in c.case_specs()}
 for case_index,case in enumerate(f.FILE_CASE_IDS):
  name=case.replace('/','-');original=attempt/'producer'/name
  prepared=f.prepare_file_fixture(case,original);keep(f'prepare-{case_index:02d}',prepared);assert isinstance(prepared,f.PreparedFileFixture)
  observations=[];calls=[]
  for index,operation in enumerate(specs[case].Calls):
   observed=f.execute_file_call(prepared,index)
   keep(f'producer-observation-{case_index:02d}-{index}',observed)
   assert isinstance(observed,f.FileCallObservation)
   if observed.CompletedOperation==1:producer_calls+=1
   assert observed.CompletedOperation==1 and observed.Failure is None
   returned=keep(f'producer-result-{case_index:02d}-{index}',observed.ActualResult)
   calls.append(r.RecordedCall(operation.Operation,operation.InputRoles,encoded(returned)))
   observations.append(observed)
  inputs=f.file_fixture_inputs(prepared,tuple(observations));keep(f'producer-inputs-{case_index:02d}',inputs);assert isinstance(inputs,a.Admitted)
  record=r.RecordedFileCase(case,inputs.value,tuple(calls));keep(f'recorded-case-{case_index:02d}',record);records.append((record,original))
 for index,(record,original) in enumerate(records):
  actual=r.replay_file_case(record,str(attempt/'replay'),fixed_case_id=f.FILE_CASE_IDS[index],producer_root=str(original))
  keep(f'actual-replay-{index:02d}',actual)
  replay_calls+=actual.CompletedOperations
  if actual.CaseMatched:matched_cases+=1
  assert actual.CaseMatched and actual.Failure is None
 assert producer_calls==replay_calls==11 and matched_cases==7
 keep('scoped-outcome',dict(SourceCommit=source,ProducerOperations=producer_calls,ReplayOperations=replay_calls,MatchedCases=matched_cases,CompleteScopedSlice=True,CompleteOuterConformance=False,RuntimeAdmitted=False,ImplementationArchiveCreated=False,RegisteredSourcesGenerated=False))
except Exception as error:
 failure=dict(Type=type(error).__module__+'.'+type(error).__qualname__,Detail=str(error))
finally:
 final=store.finalize(handle)
 value=dict(SourceCommit=source,StartedAt=started,FinishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),ProducerOperations=producer_calls,ReplayOperations=replay_calls,MatchedCases=matched_cases,Failure=failure,StoreFinalization=final,Calls=journal,Scope='seven-file-fixture-capture-only')
 result=e.encode_public_result(value,maximum_bytes=128*1024*1024)
 # External capture receipt is separately bounded; it is not recursively written to the store.
 if isinstance(result,a.Admitted):
  with (root/'.git/compiled-file-replay-actual-1-receipt.json').open('xb') as out:out.write(result.value)
 else:
  with (root/'.git/compiled-file-replay-actual-1-receipt-refusal.txt').open('x') as out:out.write(repr(result)+'\n')
 print(json.dumps(dict(ProducerOperations=producer_calls,ReplayOperations=replay_calls,MatchedCases=matched_cases,Failure=failure,Finalized=isinstance(final,store.Finalized),ReceiptEncoded=isinstance(result,a.Admitted),StoreRecords=len(journal))))
 if failure is not None or not isinstance(final,store.Finalized) or not isinstance(result,a.Admitted):raise SystemExit(1)
