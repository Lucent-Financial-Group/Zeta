from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,tarfile
root=Path.cwd();dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/file-replay';dest.mkdir(exist_ok=False)
records=[]
def retain(name,raw):
 stored=gzip.compress(raw,mtime=0);filename=name.replace('/','--')+'.gz'
 with (dest/filename).open('xb') as out:out.write(stored)
 assert gzip.decompress(stored)==raw
 records.append(dict(File=filename,Source=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding='gzip',StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
for family in ['tests','mypy','ruff','format']:
 for number in range(1,8):
  p=root/'.git'/f'compiled-file-replay-{family}-{number}.log'
  if p.exists():retain(p.name,p.read_bytes())
for name in ['compiled-file-replay-helper-before.log','compiled-file-replay-overlap-before.log','compiled-file-replay-encoding-refusal.log','capture-file-replay-encoding-refusal.py','capture-file-replay-actual-1.py','compiled-file-replay-actual-1.log','compiled-file-replay-actual-1-receipt.json','compiled-integrated-publication-9.log','compiled-file-replay-review-import.log']:
 p=root/'.git'/name;retain(name,p.read_bytes())
for p in sorted((root/'.git').glob('compiled-file-replay-pre-*.gz')):
 retain(p.name,p.read_bytes())
source_groups=[]
for source in ['e5b7720215e01ac7204dbe7888c8e7cb7bdfa7d2','e6238f8acc89c4d619c6631f0cb0111aa9258c20']:
 rows=[]
 for name in ['src/Interp.Python/zeta_interp/hidden_switch_compiled_file_fixtures.py','src/Interp.Python/tests/test_hidden_switch_compiled_file_fixtures.py','src/Interp.Python/zeta_interp/hidden_switch_compiled_file_replay.py','src/Interp.Python/tests/test_hidden_switch_compiled_file_replay.py']:
  raw=subprocess.check_output(['git','show',source+':'+name]);rows.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()));retain(source[:8]+'/'+Path(name).name,raw)
 source_groups.append(dict(SourceCommit=source,Files=rows))
fixture_summary=[]
names=[f'compiled-file-replay-fixtures-{n}' for n in range(1,8)]+['compiled-file-replay-helper-before','compiled-file-replay-overlap-before','compiled-file-replay-encoding-refusal','compiled-file-replay-actual-1','compiled-file-replay-actual-1-store-returns']
for name in names:
 directory=root/'.git'/name;rows=[]
 for base,dirs,files in os.walk(directory,followlinks=False):
  for leaf in sorted(dirs+files):
   p=Path(base)/leaf;info=p.lstat();kind='regular' if stat.S_ISREG(info.st_mode) else 'directory' if stat.S_ISDIR(info.st_mode) else 'symlink' if stat.S_ISLNK(info.st_mode) else 'other';row=dict(File=str(p.relative_to(directory)),Kind=kind,Bytes=info.st_size,Mode=stat.S_IMODE(info.st_mode))
   if kind=='regular':row['Sha256']=hashlib.sha256(p.read_bytes()).hexdigest().upper()
   if kind=='symlink':row['Target']=os.readlink(p)
   rows.append(row)
 size=sum(r['Bytes'] for r in rows if r['Kind']=='regular');assert len(rows)<10000 and size<=64*1024*1024
 tar=root/'.git'/(name+'-retained.tar')
 with tarfile.open(tar,'x',dereference=False) as f:f.add(directory,arcname=name)
 retain(name+'-inventory.json',(json.dumps(rows,indent=2)+'\n').encode());retain(tar.name,tar.read_bytes())
 fixture_summary.append(dict(Name=name,Entries=len(rows),RegularBytes=size))
# Retain each actual store artifact separately as well as the complete owned tree.
for p in sorted((root/'.git/compiled-file-replay-actual-1').glob('*.json')):
 retain('actual-store/'+p.name,p.read_bytes())
actual=json.loads((root/'.git/compiled-file-replay-actual-1.log').read_text());assert actual==dict(ProducerOperations=11,ReplayOperations=11,MatchedCases=7,Failure=None,Finalized=True,ReceiptEncoded=True,StoreRecords=56)
retain('retainer.py',Path(__file__).read_bytes())
manifest=dict(Scope='seven file cases with actual11 producer and11 replay operations; complete outer/source/runtime admission not performed',SourceGroups=source_groups,Validation=dict(FinalFocusedPassed=81,FinalFocusedSeconds=3.68,FixtureTests=34,ReplayTests=47),ActualCapture=actual,FixtureTrees=fixture_summary,Artifacts=records)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(Artifacts=len(records),FixtureTrees=fixture_summary,ActualCapture=actual)))
