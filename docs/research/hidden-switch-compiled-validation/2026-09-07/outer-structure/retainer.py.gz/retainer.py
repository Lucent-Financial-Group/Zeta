from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();dest=root/"docs/research/hidden-switch-compiled-validation/2026-09-07/outer-structure"
dest.mkdir(exist_ok=False);source="4117a6149e39c5b04569b09efeeecfa76d4c11e6"
names=[f"compiled-outer-structure-format-{i}.log" for i in range(1,6)]
names += [f"compiled-outer-structure-{kind}-{i}.log" for kind in ("tests","mypy","ruff") for i in range(1,4)]
names += ["compiled-outer-structure-c408-fix.log","compiled-outer-structure-format-check.log"]
records=[]
for name,path in [(n,root/".git"/n) for n in names]+[("retainer.py",Path(__file__))]:
 raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);(dest/(name+".gz")).write_bytes(stored)
 assert gzip.decompress(stored)==raw
 records.append(dict(File=name+".gz",Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding="gzip",StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
files=[]
for name in ("src/Interp.Python/zeta_interp/hidden_switch_compiled_outer_structure.py","src/Interp.Python/tests/test_hidden_switch_compiled_outer_structure.py"):
 raw=(root/name).read_bytes();assert raw==subprocess.check_output(["git","show",source+":"+name]);files.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
(dest/"manifest.json").write_text(json.dumps(dict(Scope="pure exact outer structure and independently bound read plan; no actual artifact reads or conformance execution",SourceCommit=source,SourceFiles=files,Artifacts=records),indent=2)+"\n")
print(json.dumps(dict(Artifacts=len(records),SourceFiles=len(files))))
