from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json

root = Path(__file__).resolve().parents[1]
attempt = root / ".git/hidden-switch-llvm-decode-attempt-3"
base = root / "docs/research/hidden-switch-compiled-validation/2026-09-07/llvm-decode-attempt-3"
base.mkdir()
outcome = json.loads((attempt / "outcome.json").read_text())
assert outcome["Complete"] is True and outcome["Failure"] is None and outcome["CleanupFailures"] == []
assert all(outcome[key] is False for key in ["RuntimeAdmitted", "BodyResolved", "ClosureAdmitted", "DumpAccess", "NewPolicyExecution"])
assert outcome["Process"]["ExitCode"] == 0 and (attempt / "helper.stderr.log").read_bytes() == b""
words = []
methods = []
for path in sorted(attempt.glob("decoded-method-*.json")):
    decoded = json.loads(path.read_text())
    original = json.loads((attempt / ("input-" + decoded["Role"] + ".json")).read_text())
    assert len(decoded["Words"]) == len(original["Words"])
    for word, expected in zip(decoded["Words"], original["Words"], strict=True):
        assert all(word[key] == value for key, value in expected.items())
    raw = b"".join(bytes.fromhex(row["Hex"]) for row in decoded["Words"])
    assert len(raw) == original["Method"]["Bytes"]
    assert hashlib.sha256(raw).hexdigest().upper() == original["Method"]["BodySha256"]
    words.extend(decoded["Words"])
    methods.append({"Role": decoded["Role"], "Words": len(decoded["Words"]), "Bytes": len(raw),
                    "CompilerPhysicalSha256": original["Method"]["BodySha256"]})
assert len(methods) == 130 and len(words) == 8665 and sum(row["Bytes"] for row in methods) == 34660
comments = [row["ImmediateComment"] for row in words if row["ImmediateComment"] is not None]
assert len(comments) == 851
raw_stdout = (attempt / "helper.stdout.log").read_bytes()
assert raw_stdout == (root / ".git/hidden-switch-llvm-decode-attempt-2/helper.stdout.log").read_bytes()
raw_input = (attempt / "decoder.input").read_bytes()
assert all(raw_input == (root / f".git/hidden-switch-llvm-decode-attempt-{index}/decoder.input").read_bytes() for index in [1, 2])
inputs = json.loads((attempt / "inputs.json").read_text())
summary = {"SourceCommit": "20043d1408bfa3a515f5d59864ad858595044707", "ExecutionHead": "1be0fa57b256d34045f3b3e5a9b2f55ce0dfe550",
           "Outcome": outcome, "Methods": methods, "InputWords": len(words), "CommentLines": len(comments),
           "RawStdoutLines": len(raw_stdout.splitlines()), "AtomicInputEqualsAttempts": [1, 2], "RawStdoutEqualsAttempt2": True,
           "InputPins": len(inputs["Pins"]), "MnemonicTextFrequency": dict(sorted(Counter(row["Instruction"].split()[0] for row in words).items())),
           "Interpretation": "Finite exact decoder/re-encoding correspondence, not interpreted targets, call/CFG/literal closure or runtime admission. Physical bytes remain local dump data; prior executed physical/compiler comparison is separately retained."}
summary_path = root / ".git/hidden-switch-llvm-decode-attempt-3-results.json"
summary_path.write_text(json.dumps(summary, indent=2) + "\n")
paths = sorted(attempt.iterdir()) + [root / ".git/hidden-switch-llvm-decode-attempt-3-invocation.json",
                                   root / ".git/hidden-switch-llvm-decode-attempt-3.log", summary_path, Path(__file__).resolve()]
records = []
for path in paths:
    raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0)
    destination = base / (path.name + ".gz")
    with destination.open("xb") as stream:
        stream.write(stored)
    records.append({"File": destination.name, "OriginalLocalFile": str(path.relative_to(root)),
                    "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest().upper(),
                    "StoredBytes": len(stored), "StoredSha256": hashlib.sha256(stored).hexdigest().upper(), "Encoding": "gzip"})
with (base / "manifest.json").open("x") as stream:
    json.dump({"SourceCommit": summary["SourceCommit"], "ExecutionHead": summary["ExecutionHead"],
               "Scope": "third actual decoder attempt, complete130method8665word correspondence only; no dump/target and all full flags false",
               "Records": records}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"Records": len(records), "Methods": len(methods), "Words": len(words), "Comments": len(comments),
                  "OriginalBytes": sum(row["Bytes"] for row in records), "StoredBytes": sum(row["StoredBytes"] for row in records),
                  "InputPins": len(inputs["Pins"])}))
