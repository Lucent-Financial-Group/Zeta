from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();source=root/'.git/compiled-native-fixtures-development';dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/native-fixtures-attempt-1';dest.mkdir(parents=True,exist_ok=False)
observed=json.loads((source/'validation.json').read_bytes());pin=observed['SourceCommit'];assert pin=='113afdb5a96e0df9894af49de102843d7caacacd'
manifest={'SourceCommit':pin,'Scope':'initial pure 38-case fixture implementation validation; baseline helper-input role under repair','SourceFiles':[],'Artifacts':[],'ActualPythonCalls':43,'PendingNativeRequests':31,'NativeLaunches':0,'RegisteredSourceGeneration':False}
paths=[row['File'] for row in observed['LoadedTaskSources']]+['src/Interp.Python/tests/test_hidden_switch_compiled_native_fixtures.py']
for path in dict.fromkeys(paths):
 raw=subprocess.check_output(['git','show',pin+':'+path]);assert raw==(root/path).read_bytes()
 manifest['SourceFiles'].append({'File':path,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
for path in sorted(source.iterdir()):
 if not path.is_file():continue
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
 with (dest/(path.name+'.gz')).open('xb') as out:out.write(packed)
 assert gzip.decompress(packed)==raw
 manifest['Artifacts'].append({'File':path.name+'.gz','Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Encoding':'gzip','StoredBytes':len(packed),'StoredSha256':hashlib.sha256(packed).hexdigest().upper()})
with (dest/'manifest.json').open('x') as out:json.dump(manifest,out,indent=2);out.write('\n')
print(json.dumps({'Artifacts':len(manifest['Artifacts']),'Sources':len(manifest['SourceFiles']),'OriginalBytes':sum(r['Bytes'] for r in manifest['Artifacts'])}))
