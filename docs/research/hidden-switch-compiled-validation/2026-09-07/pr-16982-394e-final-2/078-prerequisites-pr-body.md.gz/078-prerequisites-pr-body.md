The guarded-controller follow-on needs independently checked arithmetic, actual native hand receipts and reliable evidence recording before its registered measurements. This preserves those reviewed prerequisites and all first validation failures/recoveries, with a current continuation bootstrap. The original study and frozen protocol are unchanged.

The actual native semantic receipt passes independent replay of 222 scalar positions, 48 new hand episodes, 24 old controls, 10 invocation cases, 10 interventions and 53 invalid operations. The compiled Python subset passes 983 tests. The complete outer recorder and runtime body/call closure remain pending; this creates no implementation archive, generates no registered streams and makes no compiled speed claim. Later ClrMD helper/native-fixture source is outside this publication cutoff.

Validation: all 18 full local preflight checks pass, including release build and full native tests; independent publication review verifies all original 19 source/18 result pins, 83 Interp source/config identities and 502 local links. After that gate, two fixture-test os.write calls were moved before their assertions in response to GitHub review; all 33 affected tests and strict mypy/Ruff/format checks pass. Production source is unchanged. The earlier 83-file pin comparison and this single test-file correction are retained as separate checkpoints. The finite publication claim is released; the parent implementation claim remains active on its separate branch.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1YYRTYF087G0R003TXBK2W
Co-Authored-By: Codex <noreply@openai.com>
