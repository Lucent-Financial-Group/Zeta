from pathlib import Path
import datetime
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
pub = Path('/Users/acehack/.zeta/agents/codex/Zeta-compiled-evidence-publication-20260907')
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/pr-16982-394e-final'
dest.mkdir(exist_ok=False)
head = '394e2183084d9ec670f7a37ca6b0384e49ee7c19'
merged = json.loads((pub / '.git/pr-16982-merged-1.json').read_bytes())
merge = merged['mergeCommit']['oid']
assert merged['state'] == 'MERGED' and merged['headRefOid'] == head
subprocess.run(['git', 'merge-base', '--is-ancestor', merge, 'origin/main'], cwd=pub, check=True)
pages = json.loads((pub / '.git/pr-16982-files-2.json').read_bytes())
files = [row for page in pages for row in page]
assert len(pages) == 24 and len(files) == len({row['filename'] for row in files}) == 2314
def tree(commit):
    raw = subprocess.check_output(['git', 'ls-tree', '-rz', commit], cwd=pub)
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode() for row in raw.split(b'\0') if row}
feature_tree, merge_tree, main_tree = tree(head), tree(merge), tree('origin/main')
for row in files:
    name = row['filename']
    assert feature_tree.get(name) == merge_tree.get(name) == main_tree.get(name), name
message = subprocess.check_output(['git', 'show', '-s', '--format=%B', merge], cwd=pub).decode()
signature = (pub / '.git/prerequisites-publication-signature.txt').read_text().strip()
assert signature in message
summary = dict(ObservedAtUtc=datetime.datetime.now(datetime.UTC).isoformat(), Pr=16982, Head=head, MergeCommit=merge, MergedAt=merged['mergedAt'], MainCommit=subprocess.check_output(['git','rev-parse','origin/main'],cwd=pub).decode().strip(), Pages=24, ChangedFiles=2314, AllPublishedTreeEntriesExactOnMergeAndMain=True, MainAncestryVerified=True, CompleteSignaturePresent=True, SourceRuntimeOrScientificAdmission=False)
summary_raw = (json.dumps(summary, indent=2) + '\n').encode()
inputs=[]
for index in range(1,9):
 directory=pub/f'.git/pr-16982-gate-{index}'
 if directory.exists():
  inputs += [(str(p.relative_to(pub/'.git')),p.read_bytes()) for p in sorted(directory.iterdir()) if p.is_file()]
for p in sorted((pub/'.git').iterdir()):
 if p.is_file() and p.name.startswith('pr-16982-'):
  inputs.append((p.name,p.read_bytes()))
for name in ('prerequisites-pr-body.md','observe-prerequisites-pr-1.ts','prerequisites-final-local-proof.json','prerequisites-final-push-1.log','prerequisites-final-push-2.log'):
 inputs.append((name,(pub/'.git'/name).read_bytes()))
assert merged['body']==(pub/'.git/prerequisites-pr-body.md').read_text()
assert (pub/'.git/prerequisites-pr-body.md').read_text().strip() in message
inputs += [('proof-summary.json', summary_raw), ('preserver.py', Path(__file__).read_bytes())]
artifacts = []
for index, (name, raw) in enumerate(inputs):
    stored = gzip.compress(raw,mtime=0)
    filename = f'{index:03d}-' + name.replace('/', '--') + '.gz'
    with (dest / filename).open('xb') as out:
        out.write(stored)
    assert gzip.decompress(stored) == raw
    artifacts.append(dict(Source=name, File=filename, Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper(), Encoding='gzip', StoredBytes=len(stored), StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
with (dest / 'manifest.json').open('x') as out:
    out.write(json.dumps(dict(Scope='reviewed prerequisite publication and exact main-tree proof; not native admission', Proof=summary, Artifacts=artifacts),indent=2)+'\n')
print(json.dumps(dict(Artifacts=len(artifacts), Proof=summary)))
