import subprocess,json,datetime
from pathlib import Path
def run(args,name):
 p=subprocess.run(args,capture_output=True);Path('.git/'+name).write_bytes(p.stdout);Path('.git/'+name+'.stderr').write_bytes(p.stderr);p.check_returncode();return p.stdout
gh=['/opt/homebrew/bin/gh']
fields='number,title,url,state,headRefOid,baseRefOid,body,changedFiles,mergeable,mergeStateStatus'
b=json.loads(run(gh+['pr','view','16982','--repo','Lucent-Financial-Group/Zeta','--json',fields],'pr-16982-before-2.json'))
assert b['headRefOid']=='394e2183084d9ec670f7a37ca6b0384e49ee7c19'
pages=json.loads(run(gh+['api','--paginate','--slurp','repos/Lucent-Financial-Group/Zeta/pulls/16982/files?per_page=100'],'pr-16982-files-2.json'))
a=json.loads(run(gh+['pr','view','16982','--repo','Lucent-Financial-Group/Zeta','--json',fields],'pr-16982-after-files-2.json'))
assert all(a[k]==b[k] for k in ['headRefOid','baseRefOid','body','changedFiles'])
assert a['body']==Path('.git/prerequisites-pr-body.md').read_text()
files=[x['filename'] for page in pages for x in page];assert len(files)==len(set(files))==a['changedFiles']==2314
run(['git','fetch','origin','main'],'pr-16982-main-fetch-2.log')
local=run(['git','diff','--name-only','-z',a['baseRefOid']+'...'+a['headRefOid']],'pr-16982-local-paths-2.bin').decode().strip('\0').split('\0');assert set(local)==set(files)
proof={'ObservedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'Head':a['headRefOid'],'Base':a['baseRefOid'],'Pages':len(pages),'Files':len(files),'ExactHeadAndBodyBeforeAfter':True,'LocalPathSetMatches':True}
Path('.git/pr-16982-files-proof-2.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
