from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parents[2]
old=root/'.git/compiled-native-fixtures-development'
new=Path(__file__).resolve().parent
rows=[]
for index in range(74):
 name=f'call-{index:02d}.json'
 first=(old/name).read_bytes(); second=(new/name).read_bytes()
 assert first==second,name
 rows.append({'File':name,'Bytes':len(second),'Sha256':hashlib.sha256(second).hexdigest().upper()})
a=json.loads((old/'preparation.json').read_bytes())
b=json.loads((new/'preparation.json').read_bytes())
for key in a.keys()-{'Inputs'}: assert a[key]==b[key],key
inputs=b['Inputs']; baseline=[row for row in inputs if row['Fields']['Role']=='certificate-corpus-baseline']
assert len(baseline)==1
assert [row for row in inputs if row['Fields']['Role']!='certificate-corpus-baseline']==a['Inputs']
result={'ComparedCallArtifacts':74,'ExactCallByteEquality':True,'OtherPreparationFieldsEqual':True,'OnlyInputChange':'one exact constructor baseline NamedInput added','CallArtifacts':rows}
with (new/'comparison.json').open('x') as target: json.dump(result,target,indent=2); target.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='CallArtifacts'}))
