from __future__ import annotations
import hashlib, importlib.util, json, subprocess, sys
from pathlib import Path
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_conformance as c
from zeta_interp import hidden_switch_compiled_native_fixtures as f
from zeta_interp import hidden_switch_compiled_ieee as s
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_fixture_validation',root/'src/Interp.Python/tests/test_hidden_switch_compiled_native_fixtures.py')
assert spec is not None and spec.loader is not None
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
supplied=module.supplied.__wrapped__()
prepared=f.prepare_native_fixtures(**supplied)
assert isinstance(prepared,s.Success),prepared
batch=prepared.value

def tree(value):
 checked=c.result_tree(value)
 assert isinstance(checked,a.Admitted),checked
 return checked.value

def keep(name,value):
 raw=(json.dumps(value,indent=2,sort_keys=True,ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
 with (out/name).open('xb') as target:target.write(raw)
 return {'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()}

artifacts=[]
artifacts.append(keep('preparation.json',{'Inputs':tree(batch.Inputs),'Cases':tree(batch.Cases),'Preparation':tree(batch.Preparation),'CompletedOperation':0,'Scope':batch.Scope,'OuterAndRuntimeAdmission':batch.OuterAndRuntimeAdmission}))
rows=[];completed=pending=0
for row in batch.Cases:
 for index in range(len(row.Calls)):
  result=f.dispatch_native_fixture(batch,row.CaseId,index)
  artifact=keep(f'call-{len(rows):02d}.json',tree(result))
  artifacts.append(artifact)
  rows.append({'CaseId':row.CaseId,'CallIndex':index,'Result':artifact})
  assert not isinstance(result,f.DispatchFailure),result
  completed+=isinstance(result,f.Dispatched)
  pending+=isinstance(result,f.NativeCallPending)
assert (completed,pending)==(43,31)
sources=[]
for name,loaded in sorted(sys.modules.items()):
 if name.startswith('zeta_interp.hidden_switch') and getattr(loaded,'__file__',None):
  path=Path(loaded.__file__).resolve();raw=path.read_bytes()
  sources.append({'Module':name,'File':path.relative_to(root).as_posix(),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
result={'Schema':'zeta.hidden-switch.compiled.native-fixture-implementation-validation.v1','SourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'PythonExecutable':sys.executable,'PythonVersion':sys.version,'Cases':len(batch.Cases),'ActualPythonCalls':completed,'PendingNativeRequests':pending,'DefinedCaseSlots':len(rows),'CaseResults':rows,'Artifacts':artifacts,'LoadedTaskSources':sources,'Scope':'owned hand-derived fixture and Python checker validation only','NativeLaunches':0,'RegisteredSourceGeneration':False,'OuterAndRuntimeAdmission':'not-performed','ModuleIdentityAdmission':'not-performed; observed current-file metadata only','BindingsPremise':'placeholder numerical bindings and supplied context hashes; no final source/runtime admission'}
keep('validation.json',result)
print(json.dumps({key:result[key] for key in ('SourceCommit','Cases','ActualPythonCalls','PendingNativeRequests','DefinedCaseSlots','NativeLaunches','Scope')},indent=2))
