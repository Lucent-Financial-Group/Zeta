"""Owned empty identity fixture package."""
