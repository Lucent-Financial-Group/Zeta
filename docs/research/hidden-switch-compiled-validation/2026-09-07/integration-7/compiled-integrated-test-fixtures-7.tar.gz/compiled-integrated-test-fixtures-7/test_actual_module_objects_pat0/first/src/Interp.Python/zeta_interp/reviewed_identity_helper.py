LABEL = 'owned'
