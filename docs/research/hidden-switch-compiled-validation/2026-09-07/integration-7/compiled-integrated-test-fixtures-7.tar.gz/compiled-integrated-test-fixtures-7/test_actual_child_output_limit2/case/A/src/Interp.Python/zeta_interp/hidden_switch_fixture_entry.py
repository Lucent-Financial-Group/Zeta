import os, sys, time
from pathlib import Path
(Path(os.environ['ZETA_IDENTITY_ROOT'])/'child-trace.jsonl').write_bytes(b'x'*2048)
time.sleep(60)
