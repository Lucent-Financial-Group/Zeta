from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,tarfile
root=Path.cwd();dest=root/"docs/research/hidden-switch-compiled-validation/2026-09-07/outer-artifacts";dest.mkdir(exist_ok=False)
names=["compiled-outer-artifacts-format-1.log","compiled-outer-artifacts-format-2.log","compiled-outer-artifacts-format-check.log","compiled-outer-artifacts-tests-1.log","compiled-outer-artifacts-mypy-1.log","compiled-outer-artifacts-ruff-1.log","compiled-outer-artifact-exception-before.log","compiled-outer-artifact-exception-format.log","compiled-outer-artifact-exception-format-check.log","compiled-outer-artifact-exception-tests.log","compiled-outer-artifact-exception-mypy.log","compiled-outer-artifact-exception-ruff.log","compiled-outer-artifact-exception-ruff-2.log"]
paths=[(n,root/".git"/n) for n in names];trees=[]
for name in ("compiled-outer-artifact-fixtures-1","compiled-outer-artifact-exception-fixtures-before","compiled-outer-artifact-fixtures-2"):
 tree=root/".git"/name;inventory=[]
 for base,dirs,files in os.walk(tree,followlinks=False):
  for leaf in sorted(dirs+files):
   p=Path(base)/leaf;s=p.lstat();kind="regular" if stat.S_ISREG(s.st_mode) else "directory" if stat.S_ISDIR(s.st_mode) else "symlink" if stat.S_ISLNK(s.st_mode) else "other"
   row=dict(File=str(p.relative_to(tree)),Kind=kind,Bytes=s.st_size,Mode=stat.S_IMODE(s.st_mode))
   if kind=="regular":row["Sha256"]=hashlib.sha256(p.read_bytes()).hexdigest().upper()
   if kind=="symlink":row["Target"]=os.readlink(p)
   inventory.append(row)
 count=sum(x["Bytes"] for x in inventory if x["Kind"]=="regular");assert count<64*1024*1024 and len(inventory)<10000
 inv=root/".git"/(name+"-inventory.json");inv.write_text(json.dumps(inventory,indent=2)+"\n")
 archive=root/".git"/(name+".tar")
 with tarfile.open(archive,"x",dereference=False) as output:output.add(tree,arcname=name)
 paths.extend(((inv.name,inv),(archive.name,archive)));trees.append(dict(Name=name,Entries=len(inventory),RegularBytes=count))
paths.append(("retainer.py",Path(__file__)));records=[]
for name,path in paths:
 raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);(dest/(name+".gz")).write_bytes(stored);assert gzip.decompress(stored)==raw
 records.append(dict(File=name+".gz",Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding="gzip",StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
groups=[]
for label,commit in (("original","8c50250f8978e159be049c400973933ae638c22a"),("corrected","0e0008386865202805ab32450c298be9049228a9")):
 files=[]
 for name in ("src/Interp.Python/zeta_interp/hidden_switch_compiled_outer_artifacts.py","src/Interp.Python/tests/test_hidden_switch_compiled_outer_artifacts.py"):
  raw=subprocess.check_output(["git","show",commit+":"+name]);files.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
  if label=="corrected":assert raw==(root/name).read_bytes()
 groups.append(dict(Phase=label,SourceCommit=commit,Files=files))
name="src/Interp.Python/tests/test_hidden_switch_compiled_outer_structure.py";commit="9f8dca17624aea59e96db7c2230493997a4a6a86";raw=subprocess.check_output(["git","show",commit+":"+name]);assert raw==(root/name).read_bytes()
(dest/"manifest.json").write_text(json.dumps(dict(Scope="actual bounded strict artifact reads of synthetic outer schemas; no operation replay or registered source",SourceGroups=groups,FixtureDependency=dict(SourceCommit=commit,File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()),Trees=trees,Artifacts=records),indent=2)+"\n")
print(json.dumps(dict(Artifacts=len(records),Trees=trees)))
