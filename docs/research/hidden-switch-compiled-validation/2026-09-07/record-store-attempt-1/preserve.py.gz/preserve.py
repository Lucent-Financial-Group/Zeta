from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd(); source=root/'.git/compiled-record-store-development'; dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/record-store-attempt-1';dest.mkdir(parents=True,exist_ok=False)
observed=json.loads((source/'validation.json').read_bytes());pin=observed['SourceCommit'];assert pin=='f45a7aca501e2dc5125b5f3863ecb83862780eb0'
manifest={'SourceCommit':pin,'Scope':'bounded sequential recorder-store implementation fixtures; no operation replay or runtime admission','SourceFiles':[],'Artifacts':[],'OwnedDirectories':observed['OwnedDirectories'],'NativeLaunches':0,'PolicyCalls':0,'RegisteredSourceGeneration':False}
for path in [row['File'] for row in observed['ObservedLoadedSources']]+['src/Interp.Python/tests/test_hidden_switch_compiled_record_store.py']:
 raw=subprocess.check_output(['git','show',pin+':'+path]);assert raw==(root/path).read_bytes();manifest['SourceFiles'].append({'File':path,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
for path in sorted(source.rglob('*')):
 assert not path.is_symlink()
 if not path.is_file():continue
 raw=path.read_bytes();packed=gzip.compress(raw,mtime=0);relative=path.relative_to(source).as_posix()+'.gz';target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('xb') as output:output.write(packed)
 assert gzip.decompress(packed)==raw
 manifest['Artifacts'].append({'File':relative,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Encoding':'gzip','StoredBytes':len(packed),'StoredSha256':hashlib.sha256(packed).hexdigest().upper()})
with (dest/'manifest.json').open('x') as output:json.dump(manifest,output,indent=2);output.write('\n')
print(json.dumps({'Artifacts':len(manifest['Artifacts']),'Sources':len(manifest['SourceFiles']),'RawBytes':sum(row['Bytes'] for row in manifest['Artifacts'])}))
