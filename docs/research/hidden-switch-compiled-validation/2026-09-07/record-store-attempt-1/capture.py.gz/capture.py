from __future__ import annotations
import dataclasses,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
from unittest.mock import patch
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_record_encoding as encoding
from zeta_interp import hidden_switch_compiled_record_store as r

base=Path(__file__).resolve().parent
root=base.parents[1]
owned=base/'owned'
owned.mkdir(exist_ok=False)

@dataclasses.dataclass(frozen=True)
class ActualReturn:
    Complete: bool
    Count: int
    Raw: bytes

artifacts=[]
def keep(name,value):
    encoded=encoding.encode_public_result(value,maximum_bytes=2*1024*1024)
    assert isinstance(encoded,a.Admitted),encoded
    raw=encoded.value
    with (base/name).open('xb') as target:target.write(raw)
    artifacts.append({'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})

def opened(name,limits=r.DEFAULT_LIMITS):
    result=r.open_store(owned,name,limits)
    assert isinstance(result,r.Opened),result
    keep(name+'-open.json',result.Snapshot)
    return result.Store

store=opened('success')
first=r.append_result(store,'actual-return',ActualReturn(True,3,b'actual fixture return'))
second=r.append_bytes(store,'raw-input',b'raw\x00\xff\n')
assert isinstance(first,r.Stored) and isinstance(second,r.Stored)
keep('success-first.json',first);keep('success-second.json',second)
final=r.finalize(store);assert isinstance(final,r.Finalized),final
keep('success-final.json',final)

store=opened('partial')
prior=r.append_bytes(store,'prior',b'accepted prefix artifact');assert isinstance(prior,r.Stored)
keep('partial-prior.json',prior)
original=os.write
calls=0
def partial(fd,raw):
    global calls
    calls+=1
    if calls==1:return original(fd,raw[:4])
    raise OSError('retained fixture partial-write refusal')
with patch.object(os,'write',partial):
    failed=r.append_result(store,'actual-return',ActualReturn(False,4,b'observed before recording failure'))
assert isinstance(failed,r.StoreFailed) and failed.Attempt is not None
assert (owned/failed.Attempt.File).read_bytes()==failed.Attempt.Encoding.Returned.value[:4]
assert calls==2
keep('partial-failure.json',failed)
final=r.finalize(store);assert isinstance(final,r.Finalized),final
assert final.After.PrimaryFailure is failed.PrimaryFailure
keep('partial-final.json',final)

store=opened('quota',r.Limits(32768,16384,4))
actual=ActualReturn(True,5,b'x'*8192)
failed=r.append_result(store,'actual-return',actual)
assert isinstance(failed,r.StoreFailed) and failed.Failure.code=='record-byte-bound'
assert failed.Supplied.Value is actual
keep('quota-failure.json',failed)
final=r.finalize(store);assert isinstance(final,r.Finalized),final
keep('quota-final.json',final)

store=opened('final-collision')
prior=r.append_bytes(store,'prior',b'accepted before final failure');assert isinstance(prior,r.Stored)
keep('final-collision-prior.json',prior)
with (owned/'final-collision/final-journal.json').open('xb') as target:target.write(b'fixture preexisting final output')
failed=r.finalize(store);assert isinstance(failed,r.FinalizationFailed) and failed.Failure.code=='existing-output'
keep('final-collision-failure.json',failed)
again=r.finalize(store);assert isinstance(again,r.FinalizationFailed) and again.Failure.code=='store-finalized'
keep('final-collision-repeat.json',again)
assert (owned/'final-collision/final-journal.json').read_bytes()==b'fixture preexisting final output'

with patch.object(os,'fsync',side_effect=OSError('fixture directory fsync after mkdir')):
    ambiguous=r.open_store(owned,'ambiguous-setup')
assert isinstance(ambiguous,r.OpenFailed) and ambiguous.Ownership=='not-established'
assert (owned/'ambiguous-setup').is_dir()
keep('ambiguous-setup.json',ambiguous)

files=[];directories=[]
for path in sorted(owned.rglob('*')):
    assert not path.is_symlink()
    if path.is_dir():directories.append(path.relative_to(owned).as_posix());continue
    raw=path.read_bytes();st=path.stat()
    files.append({'File':path.relative_to(owned).as_posix(),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Device':st.st_dev,'Inode':st.st_ino,'Mode':st.st_mode})
modules=[]
for name,module in sorted(sys.modules.items()):
    if name.startswith('zeta_interp.hidden_switch'):
        path=Path(module.__file__).resolve();raw=path.read_bytes()
        modules.append({'Module':name,'File':path.relative_to(root).as_posix(),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
assert {row['Module'].rsplit('.',1)[-1] for row in modules}=={'hidden_switch_compiled_admission','hidden_switch_compiled_record_encoding','hidden_switch_compiled_record_store','hidden_switch_compiled_storage'}
result={'Schema':'zeta.hidden-switch.compiled.record-store-implementation-validation.v1','SourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'PythonExecutable':sys.executable,'PythonVersion':sys.version,'Cases':['success','partial','quota','final-collision','ambiguous-setup'],'CapturedPublicResultFiles':artifacts,'OwnedFiles':files,'OwnedDirectories':directories,'ObservedLoadedSources':modules,'Scope':'bounded implementation filesystem fixtures only','NativeLaunches':0,'PolicyCalls':0,'RegisteredSourceGeneration':False,'ModuleRuntimeAdmission':'not performed; current source observations only','OutsideStoreRetention':'This harness separately serializes actual public returns; those external evidence files are outside each tested store reservation. The final-collision fixture intentionally writes one preexisting file outside the store.'}
keep('validation.json',result)
print(json.dumps({'SourceCommit':result['SourceCommit'],'Cases':len(result['Cases']),'PublicResultFiles':len(result['CapturedPublicResultFiles']),'OwnedFiles':len(files),'OwnedDirectories':len(directories),'PolicyCalls':0,'NativeLaunches':0}))
