from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,tarfile
root=Path.cwd();dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/file-gzip-boundary';dest.mkdir(exist_ok=False)
records=[]
def retain(name,raw):
 stored=gzip.compress(raw,mtime=0);filename=name.replace('/','--')+'.gz'
 with (dest/filename).open('xb') as f:f.write(stored)
 assert gzip.decompress(stored)==raw
 records.append(dict(File=filename,Source=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding='gzip',StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
for name in ['compiled-gzip-boundary-before.log','compiled-gzip-boundary-after.log','compiled-file-replay-tests-1.log','compiled-file-replay-mypy-2.log','compiled-file-replay-ruff-2.log','compiled-file-replay-format-2.log']:
 retain(name,(root/'.git'/name).read_bytes())
for p in sorted((root/'.git/compiled-file-replay-initial-source').iterdir()):
 retain('initial-source/'+p.name, p.read_bytes())
fixture_summary=[]
for name in ['compiled-gzip-boundary-before','compiled-gzip-boundary-after']:
 directory=root/'.git'/name;rows=[]
 for base,dirs,files in os.walk(directory,followlinks=False):
  for leaf in sorted(dirs+files):
   p=Path(base)/leaf;info=p.lstat();kind='regular' if stat.S_ISREG(info.st_mode) else 'directory' if stat.S_ISDIR(info.st_mode) else 'symlink' if stat.S_ISLNK(info.st_mode) else 'other';row=dict(File=str(p.relative_to(directory)),Kind=kind,Bytes=info.st_size,Mode=stat.S_IMODE(info.st_mode))
   if kind=='regular':row['Sha256']=hashlib.sha256(p.read_bytes()).hexdigest().upper()
   if kind=='symlink':row['Target']=os.readlink(p)
   rows.append(row)
 tar=root/'.git'/(name+'.tar')
 with tarfile.open(tar,'x',dereference=False) as f:f.add(directory,arcname=name)
 retain(name+'-inventory.json',(json.dumps(rows,indent=2)+'\n').encode());retain(tar.name,tar.read_bytes())
 fixture_summary.append(dict(Name=name,Entries=len(rows),RegularBytes=sum(r['Bytes'] for r in rows if r['Kind']=='regular')))
sources=[]
for name in ['src/Interp.Python/zeta_interp/hidden_switch_compiled_file_fixtures.py','src/Interp.Python/tests/test_hidden_switch_compiled_file_fixtures.py']:
 raw=subprocess.check_output(['git','show','b62655e019914094dc443a6fc5a11d77d63197c3:'+name]);assert raw==(root/name).read_bytes();sources.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
retain('retainer.py',Path(__file__).read_bytes())
manifest=dict(Scope='fixed gzip conformance fixture boundary repair; not complete outer replay or runtime admission',CorrectedSourceCommit='b62655e019914094dc443a6fc5a11d77d63197c3',SourceFiles=sources,FixtureTrees=fixture_summary,Artifacts=records)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(Artifacts=len(records),FixtureTrees=fixture_summary)))
