from pathlib import Path
import gzip,hashlib,json,re,sys
root=Path('.').resolve();sys.path.insert(0,str(root/'src/Research.FSharp.Cli'))
from inspect_hidden_switch_bodies import parse_blocks
attempt=root/'.git/hidden-switch-llvm-decode-attempt-1';base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/llvm-decode-attempt-1';base.mkdir()
words=[]
for p in sorted(attempt.glob('input-method-*.json')):words.extend(json.loads(p.read_text())['Words'])
assert len(words)==8665
stderr=(attempt/'helper.stderr.log').read_text();positions=[int(x) for x in re.findall(r'<stdin>:(\d+):2: warning: invalid instruction encoding',stderr)]
assert len(positions)==20
failures=[{'InputLine':line,**words[line-1],'Word':f"{int.from_bytes(bytes.fromhex(words[line-1]['Hex']),'little'):08X}"} for line in positions]
assert sorted({r['Word'] for r in failures})==['B8BFC000','B8BFC021']
summary={'Source':'036c114c093d2021d5e9ff187ddceea2a0befbb5','ExecutionHead':'bea1417835b1924704c2d327a37365d2f831b2d0',
 'Outcome':json.loads((attempt/'outcome.json').read_text()),'RequestedMethods':130,'InputWords':8665,
 'StderrWarnings':20,'RawStdoutLines':len((attempt/'helper.stdout.log').read_bytes().splitlines()),'AdmittedParsedMethods':0,
 'RejectedWords':failures,'CompilerLabelObservation':'Both word values are labeled ldapr in the retained JIT; decoder feature correspondence requires separate source review.',
 'Interpretation':'Generic CPU with no added features refused. No realignment of skipped stdout rows, arithmetic/CFG/runtime admission or automatic retry.'}
summarypath=root/'.git/hidden-switch-llvm-decode-attempt-1-results.json';summarypath.write_text(json.dumps(summary,indent=2)+'\n')
paths=sorted(attempt.iterdir())+[root/'.git/hidden-switch-llvm-decode-attempt-1-invocation.json',root/'.git/hidden-switch-llvm-decode-attempt-1.log',summarypath,Path(__file__).resolve()]
records=[]
for p in paths:
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);dest=base/(p.name+'.gz');dest.write_bytes(stored)
 records.append({'File':dest.name,'OriginalLocalFile':str(p.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
(base/'manifest.json').write_text(json.dumps({'SourceCommit':summary['Source'],'ExecutionHead':summary['ExecutionHead'],'Scope':'first actual decoder refusal, no admitted parsed method; no dump or target','Records':records},indent=2)+'\n')
print(json.dumps({'Records':len(records),'InputWords':len(words),'Warnings':len(failures),'RawStdoutLines':summary['RawStdoutLines'],'Source':summary['Source']}))
