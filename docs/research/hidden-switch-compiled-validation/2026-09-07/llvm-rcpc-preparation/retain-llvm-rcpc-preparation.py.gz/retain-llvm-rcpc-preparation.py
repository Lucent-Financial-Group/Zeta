from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
source = "4a570eaf3ee2d5dccef07b5eeea229a363cd7365"
base = root / "docs/research/hidden-switch-compiled-validation/2026-09-07/llvm-rcpc-preparation"
base.mkdir()
pins = json.loads((root / ".git/hidden-switch-llvm-rcpc-source-pins.json").read_text())
for pin in pins:
    raw = (root / pin["File"]).read_bytes()
    assert len(raw) == pin["Bytes"] and hashlib.sha256(raw).hexdigest().upper() == pin["Sha256"]
    assert subprocess.check_output(["git", "show", source + ":" + pin["File"]], cwd=root) == raw
paths = [root / (".git/hidden-switch-llvm-rcpc-" + name) for name in [
    "tests-1.log", "combined-1.log", "ruff-1.log", "ruff-2.log", "tests-2.log",
    "source-pins.json", "prior-check.json", "validation.json"]] + [Path(__file__).resolve()]
records = []
for path in paths:
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    destination = base / (path.name + ".gz")
    with destination.open("xb") as stream:
        stream.write(stored)
    records.append({"File": destination.name, "OriginalLocalFile": str(path.relative_to(root)),
                    "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest().upper(),
                    "StoredBytes": len(stored), "StoredSha256": hashlib.sha256(stored).hexdigest().upper(), "Encoding": "gzip"})
with (base / "manifest.json").open("x") as stream:
    json.dump({"SourceCommit": source, "SourcePins": pins, "Scope": "pure RCPC/comment decoder preparation; no candidate, dump or target execution",
               "Records": records}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"Records": len(records), "SourceCommit": source}))
