import subprocess,json,datetime
from pathlib import Path
def run(args,name):
 p=subprocess.run(args,capture_output=True);Path('.git/'+name).write_bytes(p.stdout);Path('.git/'+name+'.stderr').write_bytes(p.stderr);p.check_returncode();return p.stdout
gh=['/opt/homebrew/bin/gh']
fields='number,title,url,state,headRefOid,baseRefOid,body,changedFiles,mergeable,mergeStateStatus'
b=json.loads(run(gh+['pr','view','16999','--repo','Lucent-Financial-Group/Zeta','--json',fields],'pr-16999-before-2.json'))
assert b['headRefOid']=='d4a0fc6a2e3d316eeac9c2688b3a159177b41dfc'
pages=json.loads(run(gh+['api','--paginate','--slurp','repos/Lucent-Financial-Group/Zeta/pulls/16999/files?per_page=100'],'pr-16999-files-2.json'))
a=json.loads(run(gh+['pr','view','16999','--repo','Lucent-Financial-Group/Zeta','--json',fields],'pr-16999-after-files-2.json'))
assert all(a[k]==b[k] for k in ['headRefOid','baseRefOid','body','changedFiles'])
assert a['body']==Path('.git/replay-publication-pr-body.md').read_text()
files=[x['filename'] for page in pages for x in page];assert len(files)==len(set(files))==a['changedFiles']; assert 0<len(files)<3000
run(['git','fetch','origin','main'],'pr-16999-main-fetch-2.log')
local=run(['git','diff','--name-only','-z',a['baseRefOid']+'...'+a['headRefOid']],'pr-16999-local-paths-2.bin').decode().strip('\0').split('\0');assert set(local)==set(files)
proof={'ObservedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'Head':a['headRefOid'],'Base':a['baseRefOid'],'Pages':len(pages),'Files':len(files),'ExactHeadAndBodyBeforeAfter':True,'LocalPathSetMatches':True}
Path('.git/pr-16999-files-proof-2.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
