## What changed and why

The compiled-controller experiment needed reproducible checks of its file, identity and native-code evidence before its final execution boundary could be admitted. This preserves the reviewed static/file/identity replay implementations, bounded outer artifact reads and record storage, copied-target custody, all 130 current native method extents and their 8,665-word LLVM correspondence. Failed attempts and corrections remain separately indexed and byte-addressed.

The publication has 31 changed source/test files, independently checked against the accepted owner source pins and integration cut. Six other source differences from that integration cut are inherited main changes, explicitly identified by the review. The original study and frozen compiled protocol are unchanged. Complete 92-case outer replay, runtime body/call closure and the final envelope chain remain pending; no implementation archive or registered 9307/9409 measurement is created.

## Validation

- Full local repository gate: all 18 checks pass at `be839a0c4784b25c35eb4a1cfb43fe087c11c999`; subsequent changes are review/evidence documentation and finite-claim release.
- The first full gate's JVM SIGSEGV is retained with its complete TLC diagnostic tree, unchanged one-test retry and successful full retry. No cause is inferred from recovery.
- Native Python helper discovery: 67 tests pass. The earlier integrated cut passed 1,259 compiled Python tests; later identity/decoder sources have their own focused validation and independent reviews.
- Final ordinary push: all 16 quick checks pass. Four canonical WIP refs preserve original writer history and were independently remote-read verified.

See [publication record](docs/research/2026-09-08-hidden-switch-compiled-replay-custody-publication.md), [independent source review](docs/research/2026-09-08-hidden-switch-compiled-replay-publication-review.md), and [gate evidence](docs/research/hidden-switch-compiled-validation/2026-09-08/replay-publication-gates/README.md). The finite publication work item remains open for exact main proof after merge; the parent experiment remains active.
