from pathlib import Path
import gzip, hashlib, json, subprocess
root=Path.cwd()
source="be839a0c4784b25c35eb4a1cfb43fe087c11c999"
dest=root/"docs/research/hidden-switch-compiled-validation/2026-09-08/replay-publication-gates"
dest.mkdir(parents=True,exist_ok=True)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
records=[]
def put(name,raw):
    stored=gzip.compress(raw,mtime=0)
    path=dest/(name+".gz")
    assert not path.exists() or path.read_bytes()==stored
    path.write_bytes(stored)
    records.append(dict(File=path.name,Bytes=len(raw),Sha256=sha(raw),StoredBytes=len(stored),StoredSha256=sha(stored),Encoding="gzip"))
old=root/".git/replay-publication-failed-gate-retained"
manifest=json.loads((old/"manifest.json").read_bytes())
for item in manifest["Artifacts"]:
    stored=(old/item["File"]).read_bytes(); raw=gzip.decompress(stored)
    assert sha(stored)==item["StoredSha256"] and sha(raw)==item["Sha256"]
    put(item["File"][:-3],raw)
put("failed-gate-retention-manifest.json",(old/"manifest.json").read_bytes())
for name in ["replay-publication-full-preflight-2.log","replay-publication-native-helper-tests-1.log","replay-publication-claim-push-1.log","replay-publication-integration-1.log","replay-publication-history-push-1.log","replay-publication-history-refs-1.log"]:
    put(name,(root/".git"/name).read_bytes())
assert b"all 18 executed check(s) passed" in (root/".git/replay-publication-full-preflight-2.log").read_bytes()
tree=subprocess.check_output(["git","ls-tree","-r","-z",source])
put("tested-source-tree.bin",tree)
base=subprocess.check_output(["git","merge-base",source,"origin/main"],text=True).strip()
changed=subprocess.check_output(["git","diff","--name-only","-z",base,source]).split(b"\0")
pins=[]
for encoded in changed:
    if not encoded: continue
    name=encoded.decode()
    if not name.startswith(("src/","tests/")): continue
    raw=subprocess.check_output(["git","show",source+":"+name])
    assert (root/name).read_bytes()==raw
    pins.append(dict(Path=name,Bytes=len(raw),Sha256=sha(raw)))
assert len(pins)==31
put("changed-source-pins.json",(json.dumps(dict(SourceCommit=source,ComparedBase=base,SourceFiles=pins),indent=2)+"\n").encode())
protocol=root/"docs/research/2026-09-07-hidden-switch-compiled-protocol.md"
assert sha(protocol.read_bytes())=="8bbdfe44a0844dd8ce4f6c5dd77b060a56e5b84ea94ea7a6fdbb482aec9d738a"
put("retainer.py",Path(__file__).read_bytes())
result=dict(SourceCommit=source,ComparedBase=base,FullGateAttempts=[dict(Attempt=1,Exit=1,PassedChecks=17,FailedCheck="dotnet test",ObservedFailure="TLC JVM SIGSEGV; cause unassigned"),dict(Attempt=2,Exit=0,PassedChecks=18,SourceUnchanged=True)],TargetedUnchangedRetry=dict(Passed=1,Failed=0,Skipped=0),NativeHelperUnitTests=dict(Passed=67,NewTargetExecution=False),CrashDiagnosticEntries=114,ChangedSourceFiles=len(pins),ArtifactCount=len(records),Artifacts=records,Scope="Local validation and source preservation only; runtime/body/closure admission and registered measurements remain pending.")
(dest/"manifest.json").write_text(json.dumps(result,indent=2)+"\n")
(dest/"README.md").write_text("""# Replay publication: local gates and retained failure

Date: 2026-09-08 UTC
Operational status: research-grade
Author: Vera, OpenAI Codex using GPT-6 Astra
Source commit: `be839a0c4784b25c35eb4a1cfb43fe087c11c999`

The [manifest](manifest.json) binds complete lossless logs, all 114 entries of
the first TLC crash diagnostic tree, the original Git tree, 31 changed
source/test files and the source-history push/read receipts. Every gzip record
has separate raw and stored byte counts and SHA-256 digests. The complete
retainer is included. These are engineering checks, not study observations.

The first full gate passed 17 checks and failed `dotnet test`: Java reported
SIGSEGV in the `QuorumCollateralDeterrenceR2` TLC process. The original log,
JVM diagnostic, invocation, models and all diagnostic entries remain present.
The unchanged targeted retry passed one test. The subsequent unchanged full
gate passed all 18 checks. No source edit or causal explanation is assigned to
that recovery, and no aggregate native test count is inferred from a quiet
gate log. The separate native helper discovery passed 67 Python unit tests;
it did not invoke a target, fresh dump or registered source.

The initial claim-push output is retained but is not assigned an exact-source
validation claim because integration began during that preflight. The two
full gates above ran after the integration source commit. The later WIP push
and remote read preserve the four canonical source-history branches; these
refs certify reachability, not runtime admission.

The frozen compiled protocol is byte-identical. Complete outer replay,
runtime body/call closure and the final envelope chain remain open. This
record creates no implementation archive or 9307/9409 measurement.
""")
print(json.dumps(dict(Destination=str(dest),Artifacts=len(records),ChangedSourceFiles=len(pins))))
