The learning program now targets composable probabilistic DAGs whose modules can contain neural learners and nested graphs. This change fixes a prerequisite ledger bug: a reduced grant cap previously removed already-earned privacy budget, and large grants could overflow. It also adds executable known-answer controls for distribution shape, reused consensus evidence, and the distinction between Vision funding confidence and posterior uncertainty.

Five source/test files change: PrivacyEconomy and its tests, the F# control room, and its independent Python reference/validator and tests. The accompanying evidence preserves original failures, repairs, complete process streams and independent reviews. The Yang-Mills talk is indexed in `ip-questionable`, with Aaron's computer-science scope and the existing fabricated-memory/cartel threat model grounded in current detectors and formal analysis.

This supersedes PR #17021: its 278-commit history exceeded the commit-list API's 250-message validation ceiling. The original branch and refusal are retained. This fresh-main publication preserves the reviewed implementation and explicitly audits all 231 changed tree paths; the rename-aware display has 230 names. The retained count-helper assertion failure and successful repair are documented separately.

Validation:

- Both original and successor ordinary pushes passed all 16 quick checks; the successor branch head was independently remote-read verified.

- Complete local preflight: all 18 checks pass at `19efca924f6765bbdd3b4017f707fa8f08302bd1`, including release build and full tests. Later changes are documentation and claim release; all five source/test byte identities remain unchanged.
- Five fresh F# process controls return the expected exits and independently validate, including exact fault prefixes. The Python reference suite passes 124 tests.
- The PrivacyEconomy repair passes 16 focused cases; prior compiler/runtime failures and unchanged-source successful retries remain separately retained.

See the publication record at `docs/research/2026-09-08-distributional-learning-controls-publication.md`, its linked scope review, and `docs/research/distributional-learning/2026-09-08/publication-validation/README.md`.

These are tested prerequisites. No combined learned-system performance, state-of-the-art superiority, universal cartel detection or Yang-Mills physics proof is asserted. The previously registered compiled experiment remains unopened. The finite publication work item stays open until exact main verification; parent claims remain in their writer histories.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1ZCHPWV087G0R002GG2PKY
Co-Authored-By: Codex <noreply@openai.com>
