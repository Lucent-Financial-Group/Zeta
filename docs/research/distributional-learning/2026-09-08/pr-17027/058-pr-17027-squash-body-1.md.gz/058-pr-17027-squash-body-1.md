Preserve existing privacy balances when grant caps fall, validate fixed distributional inference rooms against an independent reference, and retain source and validation records.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1ZCHPWV087G0R002GG2PKY
Co-Authored-By: Codex <noreply@openai.com>
