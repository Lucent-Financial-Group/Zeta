from pathlib import Path
from dataclasses import fields, is_dataclass
import base64
import hashlib
import json
from zeta_interp.distributional_learning_rooms_reference import validate_room_ndjson, RoomRunValidated

base = Path('../../.git')
def encode(value):
    if is_dataclass(value):
        return {"Type": type(value).__name__, "Fields": {f.name: encode(getattr(value, f.name)) for f in fields(value)}}
    if isinstance(value, bytes):
        return {"Encoding": "base64", "Bytes": len(value), "Sha256": hashlib.sha256(value).hexdigest(), "Data": base64.b64encode(value).decode('ascii')}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    return value
ordinary = (base / 'distributional-publication-room-ordinary-1.stdout').read_bytes()
results = []
for label in ['ordinary', 'fault-2', 'fault-12', 'fault-25', 'invalid-control']:
    raw = (base / ('distributional-publication-room-' + label + '-1.stdout')).read_bytes()
    result = validate_room_ndjson(raw, mode=label, ordinary_raw=ordinary if label.startswith('fault-') else None)
    results.append(dict(Label=label, Return=encode(result)))
    destination = base / ('distributional-publication-replay-' + label + '-1.json')
    assert not destination.exists()
    destination.write_text(json.dumps(results[-1], indent=2, allow_nan=False) + '\n')
    print(label, type(result).__name__, result.CheckedCheckpoints, flush=True)
    assert isinstance(result, RoomRunValidated)
summary = base / 'distributional-publication-replay-results-1.json'
assert not summary.exists()
summary.write_text(json.dumps(results, indent=2, allow_nan=False) + '\n')
