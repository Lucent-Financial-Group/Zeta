from pathlib import Path
import datetime
import hashlib
import json
import subprocess

source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert source == 'b65679674760e64bfe34e903646a2fd211d2420d'
script = Path('src/Research.FSharp/DistributionalLearningRooms.fsx')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source_hash = sha(script.read_bytes())
records = []
roster = [('ordinary', [], 0), ('fault-2', ['--fault-after-checkpoint', '2'], 2), ('fault-12', ['--fault-after-checkpoint', '12'], 2), ('fault-25', ['--fault-after-checkpoint', '25'], 2), ('invalid-control', ['--not-a-control'], 2)]
for label, args, expected_exit in roster:
    command = ['dotnet', 'fsi', '--exec', str(script), *args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    timed_out = False
    try:
        child = subprocess.run(command, capture_output=True, timeout=60)
        stdout, stderr, exit_code = child.stdout, child.stderr, child.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr, exit_code = error.stdout or b'', error.stderr or b'', None
        timed_out = True
    base = Path('.git') / ('distributional-publication-room-' + label + '-1')
    for extension, raw in [('stdout', stdout), ('stderr', stderr)]:
        destination = base.with_suffix('.' + extension)
        assert not destination.exists()
        destination.write_bytes(raw)
    row = dict(Label=label, SourceCommit=source, SourceSha256=source_hash, Command=command, StartedAt=started, FinishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), ExitCode=exit_code, TimedOut=timed_out, StdoutBytes=len(stdout), StderrBytes=len(stderr), StdoutSha256=sha(stdout), StderrSha256=sha(stderr))
    base.with_suffix('.json').write_text(json.dumps(row, indent=2) + '\n')
    records.append(row)
    Path('.git/distributional-publication-room-control-runs-1.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label, exit_code, len(stdout), len(stderr), flush=True)
    assert sha(script.read_bytes()) == source_hash
    assert exit_code == expected_exit and not timed_out
print('All five actual process outcomes match the fixed control roster', flush=True)
