from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
dest = root / 'docs/research/distributional-learning/2026-09-08/publication-validation'
files = sorted(p for p in (root / '.git').glob('distributional-publication-*') if p.is_file())
assert len(files) <= 128 and sum(p.stat().st_size for p in files) <= 8 * 1024 * 1024
dest.mkdir(parents=True, exist_ok=True)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
records = []

def put(name, raw):
    stored = gzip.compress(raw, mtime=0)
    target = dest / (name + '.gz')
    assert not target.exists() or target.read_bytes() == stored
    target.write_bytes(stored)
    records.append(dict(File=target.name, Bytes=len(raw), Sha256=sha(raw), StoredBytes=len(stored), StoredSha256=sha(stored), Encoding='gzip'))

for path in files:
    put(path.name, path.read_bytes())
put('retainer.py', Path(__file__).read_bytes())
gate_source = '19efca924f6765bbdd3b4017f707fa8f08302bd1'
room_source = 'b65679674760e64bfe34e903646a2fd211d2420d'
source_pins = json.loads((root / '.git/distributional-publication-source-pins-1.json').read_bytes())
for row in source_pins['SourceFiles']:
    for source in [gate_source, room_source]:
        raw = subprocess.check_output(['git', 'show', source + ':' + row['Path']])
        assert len(raw) == row['Bytes'] and sha(raw) == row['Sha256']
runs = json.loads((root / '.git/distributional-publication-room-control-runs-1.json').read_bytes())
results = json.loads((root / '.git/distributional-publication-replay-results-1.json').read_bytes())
assert len(runs) == len(results) == 5
assert [r['ExitCode'] for r in runs] == [0, 2, 2, 2, 2]
for run, result in zip(runs, results):
    assert run['SourceCommit'] == room_source and not run['TimedOut']
    assert run['Label'] == result['Label'] and result['Return']['Type'] == 'RoomRunValidated'
    assert run['StdoutSha256'].upper() == result['Return']['Fields']['Sha256'].upper()
manifest = dict(FullGateSource=gate_source, FullGate=dict(ExitCode=0, PassedChecks=18), ActualControlsSource=room_source, FocusedReferenceTests=dict(ExitCode=0, Passed=124, Seconds=29.92), ActualProcessRuns=runs, CompleteRuntimeClosureAdmitted=False, SourceFiles=source_pins['SourceFiles'], ArtifactCount=len(records), Artifacts=records)
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(dest / 'README.md').write_text('''# Distributional publication: full gate and fresh room validation

Date: 2026-09-08 UTC
Operational status: research-grade
Author: Vera, OpenAI Codex using GPT-6 Astra
Work item: 081M1ZCHPWV087G0R002GG2PKY

The publication full gate passed all 18 checks at
`19efca924f6765bbdd3b4017f707fa8f08302bd1`. It includes release build
and complete tests. At the later documentation cut
`b65679674760e64bfe34e903646a2fd211d2420d`, all five fresh actual F#
controls returned the expected exits: ordinary zero, injected faults and invalid
argument two. Independent reference validation accepts every complete stream
and the exact ordinary prefixes. The focused 124-test suite passed in 29.92
seconds. All five source/test files are identical across these two cuts and
the previously reviewed coordinator source.

The [manifest](manifest.json) retains complete commands, stdout/stderr, process
records, all public validation-return trees and source hashes. The fresh runtime
assembly observations belong to these processes. Prior root-writer runs keep
their original source/runtime observations. Full runtime closure remains false.

## Retained publication correction

The initial `git rm` refused two parent claims staged by the merge. The shell
continued, so the original integration and gate source still contained them.
Independent review found the discrepancy. The original log remains retained;
after the full gate closed, commit `70e81a8e2cd0b75e6acdb1d43baeb2f9dfcdba0f`
actually removed only those two publication copies and corrected the chronology.
The coordinator's active claim copies remain intact and remotely preserved.

## Local interpreter setup

The first publication reference invocation initialized its project-local uv
environment using the existing lock and CPython 3.14.6, installing 109 packages.
Its full setup output is retained in the replay log. A shell-startup mise warning
reported that the environment did not yet exist; that tool-visible warning was
not part of the redirected child log and is not represented as a raw artifact.
No new JAX/POPGym stack, model training or external tracking was installed or run.

These are deterministic known-answer controls and regression tests. They do not
establish learned-DAG quality or superiority over an external baseline. Aaron's
compositional-circuit direction is retained in the linked research program.
''')
print(json.dumps(dict(Artifacts=len(records), RawBytes=sum(row['Bytes'] for row in records))))
