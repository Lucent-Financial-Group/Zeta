from pathlib import Path
import gzip, hashlib, json, subprocess

root = Path.cwd()
dest = root / 'docs/research/distributional-learning/2026-09-08/privacy-grant-repair'
dest.mkdir(parents=True, exist_ok=True)
source = 'e2a8f7fb23b57aba614da2499273f679bf0935ad'
before = 'bd229f56aafb9a387285f59b198bb4b1bc6d5c2e'
sha = lambda b: hashlib.sha256(b).hexdigest()
records = []

def put(name, raw):
    stored = gzip.compress(raw, mtime=0)
    p = dest / (name + '.gz')
    assert not p.exists() or p.read_bytes() == stored
    p.write_bytes(stored)
    records.append(dict(File=p.name, Bytes=len(raw), Sha256=sha(raw), StoredBytes=len(stored), StoredSha256=sha(stored), Encoding='gzip'))

for name in ['privacy-budget-regressions-before.log', 'privacy-budget-regressions-before-retry.log', 'privacy-budget-regressions-after.log', 'privacy-and-compiled-full-preflight-1.log', 'privacy-budget-existing-contract-probe.fsx', 'privacy-budget-existing-contract-probe.log']:
    put(name, (root / '.git' / name).read_bytes())
for commit, path, name in [(before, 'src/Core/PrivacyEconomy.fs', 'before-PrivacyEconomy.fs'), (source, 'src/Core/PrivacyEconomy.fs', 'after-PrivacyEconomy.fs'), (source, 'tests/Tests.FSharp/PrivacyEconomy.Tests.fs', 'regression-tests.fs')]:
    put(name, subprocess.check_output(['git', 'show', commit + ':' + path]))

selected = []
for name in ['dotnet-2026-09-07-203653.ips', 'dotnet-2026-09-07-205515.ips']:
    p = Path.home() / 'Library/Logs/DiagnosticReports' / name
    raw = p.read_bytes()
    _, body = raw.split(b'\n', 1)
    j = json.loads(body)
    row = {k: j.get(k) for k in ['captureTime', 'pid', 'procName', 'parentProc', 'parentPid', 'exception', 'termination', 'faultingThread']}
    row.update(OriginalFileName=name, OriginalBytes=len(raw), OriginalSha256=sha(raw), TopFrames=j['threads'][j['faultingThread']]['frames'][:10])
    selected.append(row)
put('selected-os-diagnostics.json', (json.dumps(dict(Scope='Selected structural diagnostics; complete OS reports remain local, not represented as retained repository artifacts.', Reports=selected), indent=2) + '\n').encode())
put('retainer.py', Path(__file__).read_bytes())
manifest = dict(BeforeImplementationCommit=before, RepairedImplementationCommit=source, TestSourceCommit=source, TargetedAttempts=[dict(Attempt=1, Exit=1, Observed='Compiler exited139; no tests ran'), dict(Attempt=2, Exit=1, Passed=9, Failed=7, OriginalImplementationUnchanged=True), dict(Attempt=3, Exit=0, Passed=16, Failed=0, BoundaryGridCombinations=512)], InitialFullGate=dict(PassedChecks=16, FailedChecks=['dotnet build', 'dotnet test'], Observed='Compiler exit139 and test process exit139; no passing full-gate claim'), ArtifactCount=len(records), Artifacts=records)
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(dest / 'README.md').write_text('''# Privacy grants: cap and integer-boundary repair

Date: 2026-09-08 UTC
Operational status: research-grade
Author: Vera, OpenAI Codex using GPT-6 Astra
Work item: 081M1Z63YMC087G0R003N5FH9X
Repair source: `e2a8f7fb23b57aba614da2499273f679bf0935ad`

The existing reward function could reduce an earned entitlement when a cap
fell, and could overflow an Int32 sum into a negative balance. The repair
normalizes only an invalid negative target balance upward to zero, takes the
existing holding as the minimum ceiling, and clamps an Int64 sum before
conversion. It evaluates the supplied gain function once and leaves unrelated
entries unchanged. No distributed merge, transfer or physical-money conversion
is added. The documented object is a local grant ledger.

The [manifest](manifest.json) preserves every targeted attempt and the first
full gate with separate raw/stored byte hashes. The initial targeted attempt
lost its compiler with exit 139 and ran no tests. The unchanged retry ran all
16 tests: seven failed and nine passed. After the source repair, all 16 passed,
including the 512-combination boundary grid. These tests distinguish actual
lower-cap revocation and integer overflow from the documented contract.

The initial full gate passed 16 checks but failed both release build and full
tests after compiler/test-process exit 139. This is not a passing full gate.
Two timestamped OS reports show SIGSEGV in server-GC background frames; only
selected structural diagnostics are published, with hashes identifying the
complete reports retained locally. Their collection does not prove a cause or
identify every failing process. The separate publication writer's successful
full gate is a different source cut and is not substituted for this result.

The source and tests, original probes and all command logs are retained
losslessly. Further validation is appended separately so the failed attempts
remain visible. This repair is a prerequisite for trustworthy resource tests,
not evidence that a combined learning system outperforms a baseline.
''')
print(json.dumps(dict(Artifacts=len(records), Destination=str(dest))))
