from pathlib import Path
import gzip, hashlib, json, subprocess
root=Path.cwd(); dest=root/'docs/research/distributional-learning/2026-09-08/publication-successor'
assert not dest.exists();dest.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=set()
for pattern in ['distributional-successor-*','pr-17021-*']:
 for p in (root/'.git').glob(pattern):
  if p.is_file():paths.add(p)
  elif p.is_dir():paths.update(q for q in p.rglob('*') if q.is_file())
for name in ['distributional-publication-push-1.log','distributional-publication-remote-1.txt','distributional-publication-pr-create-1.log','distributional-publication-pr-body.md','distributional-publication-pr-first-1.json','distributional-publication-github-status-1.json','distributional-final-review-import-1.log','distributional-yang-source-import-1.log','distributional-yang-source-correction-import-1.log']:
 paths.add(root/'.git'/name)
paths.add(Path(__file__).resolve())
assert len(paths)<=128 and sum(p.stat().st_size for p in paths)<=16*1024*1024
records=[]
for i,p in enumerate(sorted(paths)):
 raw=p.read_bytes(); stored=gzip.compress(raw,mtime=0); name=f'{i:03d}-{p.name}.gz';(dest/name).write_bytes(stored)
 records.append(dict(File=name,OriginalPath=str(p.relative_to(root/'.git')),Bytes=len(raw),Sha256=sha(raw),StoredBytes=len(stored),StoredSha256=sha(stored),Encoding='gzip'))
source=json.loads((root/'.git/distributional-publication-source-pins-1.json').read_bytes())['SourceFiles']
for x in source:
 raw=subprocess.check_output(['git','show',':'+x['Path']]);assert sha(raw)==x['Sha256'] and len(raw)==x['Bytes']
tree=json.loads((root/'.git/distributional-successor-tree-before-docs-1.json').read_bytes());assert len(tree['PublicationPaths'])==230 and not tree['Mismatches']
manifest=dict(OriginalHead=tree['Original'],SuccessorBase=tree['SuccessorBase'],OriginalPr=17021,ObservedCommitTotal=278,ApiCommitMessagesSupplied=250,PublicationPathCount=230,AllOriginalPublicationEntriesIdenticalBeforeExplanation=True,SourceFiles=source,ArtifactCount=len(records),Artifacts=records)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text('''# Publication successor: retain the commit-coverage refusal

Date: 2026-09-08 UTC
Operational status: research-grade
Author: Vera, OpenAI Codex using GPT-6 Astra
Work item: 081M1ZCHPWV087G0R002GG2PKY

The first publication [PR #17021](https://github.com/Lucent-Financial-Group/Zeta/pull/17021)
passed all 16 ordinary push checks, but its AgencySignature workflow refused
incomplete commit-message coverage: the API supplied 250 of 278 messages.
The full failure log, first PR body, bounded observation, push and remote
verification are retained in the [manifest](manifest.json). No signature
failure is inferred in the unread portion, and the truncated check is not
reported as a pass. Other CI jobs were still running at the retained observation.

A new publication branch starts from main
`4d69d7a8cf77fed897c11bb179713ca67692c22f` and applies the reviewed
changes with an ordinary three-way squash. All 230 original publication paths
matched the original mode/blob or deletion in the new index before adding
this explanation and correction of the completed claim-release tense. All
five source/test byte identities still match the earlier complete local gate
and fresh controls. The earlier branch retains its full history; no published
commit is rewritten. The new commit still needs normal push and GitHub gates.
''')
print(json.dumps(dict(Artifacts=len(records),RawBytes=sum(x['Bytes'] for x in records))))
