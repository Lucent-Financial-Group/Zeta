from pathlib import Path
import subprocess,json,hashlib,datetime
old='8cb522b2dab2fb50792a3d7ff6ef7f3af21f5e64';base='5585c17c81e06878570bb1630786473e7fbec27f'
run=lambda *a:subprocess.check_output(['git',*a])
head=run('rev-parse','HEAD').decode().strip()
paths=run('diff','--no-renames','--name-only','-z',base,old).decode().split('\0')[:-1]
def entry(ref,path):
 row=run('ls-tree',ref,'--',path).decode().split()
 return dict(Mode=row[0],Type=row[1],Object=row[2]) if row else None
rows=[dict(Path=p,Original=entry(old,p),Successor=entry(head,p)) for p in paths]
diffs=[r for r in rows if r['Original']!=r['Successor']]
assert len(paths)==231
assert [r['Path'] for r in diffs]==['docs/research/2026-09-08-distributional-learning-controls-publication.md']
oldpath='workitems/081M1Z5ZW1T087G0R0002KPWJ8-publish-reviewed-compiled-replay-and-native-custody-evidence.md'
assert any(r['Path']==oldpath and r['Original'] is None and r['Successor'] is None for r in rows)
result=dict(ObservedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),OriginalHead=old,OriginalBase=base,SuccessorHead=head,RenameAwareDiffNames=230,ChangedTreePaths=len(rows),Rows=rows,DeclaredExplanationDifference=diffs)
print(json.dumps(result,indent=2))
