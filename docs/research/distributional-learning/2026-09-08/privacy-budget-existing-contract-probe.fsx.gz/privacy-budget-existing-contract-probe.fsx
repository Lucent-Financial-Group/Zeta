#load "../src/Core/PrivacyEconomy.fs"
open Zeta.Core
let rows = [ "lower-cap", 100, 10, 0; "negative-cap", 100, -1, 0; "overflow", System.Int32.MaxValue - 5, System.Int32.MaxValue, 10 ]
for name, held, cap, grant in rows do
    let initial = Map.ofList [ "probe", held ]
    let result = PrivacyEconomy.reward (fun _ -> grant) cap { Persona = "probe"; Revealed = 0.0 } initial
    let after = PrivacyEconomy.budget "probe" result
    printfn "%s held=%d cap=%d grant=%d after=%d monotone=%b" name held cap grant after (after >= held)
