Clarify the user's preference for deliberate multi-oracle choice and conspicuous disclosure when no oracle was explicitly selected. The original manifesto section and operative HC-8 non-coercion rule remain byte-identical; this change corrects explanations and adds the requested clarification without introducing a runtime chooser or deciding warning versus mandatory choice.

Correct two source comments: Omega=-1 saturates the stated Tsirelson identity, and a supra-quantum numeric band is not itself a signalling test. Executable source lines in those two files are unchanged. The bounded interface census and independent source reviews are retained.

Validation: full preflight passed all 18 checks before and after current-main composition, with exact source and merge-tree audits. Formatter exited zero with its F#-unsupported limitation retained. The PR also preserves PR17041's normal main publication proof, including its original rename-aware path-count defect and the independently verified 347-path correction. Initial environment, packaging and merge-conflict records remain available.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1Z63YMC087G0R003N5FH9X
Co-Authored-By: Codex <noreply@openai.com>
